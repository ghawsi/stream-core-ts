import * as React from "react"

import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Pagination aria-label="Minimal pagination">
      <PaginationContent>
        <PaginationItem>
          <PaginationPrevious href="#pagination" />
        </PaginationItem>
        <PaginationItem>
          <PaginationLink href="#pagination" isActive>
            1
          </PaginationLink>
        </PaginationItem>
        <PaginationItem>
          <PaginationNext href="#pagination" />
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [page, setPage] = React.useState(2)
  const last = 12
  const go = (target: number) => (event: React.MouseEvent) => {
    event.preventDefault()
    setPage(Math.min(last, Math.max(1, target)))
  }
  const pages = [1, 2, 3]

  return (
    <div className="grid gap-2">
      <Pagination aria-label="Search results pages">
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious href="#pagination" onClick={go(page - 1)} aria-disabled={page === 1} />
          </PaginationItem>
          {pages.map((number) => (
            <PaginationItem key={number}>
              <PaginationLink href="#pagination" isActive={page === number} onClick={go(number)} aria-label={`Page ${number}`}>
                {number}
              </PaginationLink>
            </PaginationItem>
          ))}
          <PaginationItem>
            <PaginationEllipsis />
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href="#pagination" size="default" isActive={page === last} onClick={go(last)} aria-label={`Page ${last}, last page`}>
              {last}
            </PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationNext href="#pagination" onClick={go(page + 1)} aria-disabled={page === last} />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
      <p className="text-center text-sm text-muted-foreground" aria-live="polite">
        Page {page} of {last}
      </p>
    </div>
  )
}
// #endregion composed
