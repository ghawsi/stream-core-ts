# Theming

How the tokens work, how to change the brand colour, the radius scale and the chart colours, and how to check contrast before a change is adopted.

## 1. How the token layer works

The components never name a colour. They use Tailwind classes such as `bg-primary` or `text-muted-foreground`. Tailwind resolves each class through a mapping to a CSS custom property, and the custom property has one value for the light theme and one for the dark theme.

```css
/* src/theme/tokens.css (excerpt) */
@theme inline {
  --color-primary: var(--primary);                    /* Tailwind: bg-primary, text-primary, ... */
  --color-primary-foreground: var(--primary-foreground);
  --radius-md: calc(var(--radius) * 0.8);             /* Tailwind: rounded-md */
}

:root {            /* light */
  --primary: oklch(0% 0 0);
  --primary-foreground: oklch(0.985 0 0);
  --radius: 0.625rem;
}

.dark {            /* dark: any element below one that has the class `dark` */
  --primary: oklch(0.922 0 0);
  --primary-foreground: oklch(0.205 0 0);
}
```

- **Semantic pairs.** A surface token has a companion for the content on it: `primary` and `primary-foreground`, `card` and `card-foreground`, `muted` and `muted-foreground`. Use them together.
- **Colour space.** Values are written in OKLCH (lightness, chroma, hue). Changing only the lightness keeps the hue.
- **Theme switch.** `ThemeProvider` sets the class `dark` on `<html>` and stores the preference (`light`, `dark` or `system`). Without the provider the light theme applies.
- **The same data in other formats.** `tokens/tokens.json` (W3C Design Tokens 2025.10, light), `tokens/tokens.dark.json` (dark overrides), `tokens/resolver.json` (combines both) and `src/theme/tokens.ts` (typed names) are generated from `tokens.css`.

The default values are the upstream shadcn/ui values, unchanged. The full list, with the light and dark value of each token, is in `docs/AUDIT.md`, section 2.

### Tokens

| Group | Tokens |
|---|---|
| Page and surfaces | `background`, `foreground`, `card`, `card-foreground`, `popover`, `popover-foreground` |
| Actions | `primary`, `primary-foreground`, `secondary`, `secondary-foreground`, `accent`, `accent-foreground` |
| Quiet content | `muted`, `muted-foreground` |
| Errors | `destructive`, `on-destructive` (added) |
| Lines and focus | `border`, `input`, `ring` |
| Charts | `chart-1` to `chart-5` |
| Sidebar | `sidebar`, `sidebar-foreground`, `sidebar-primary`, `sidebar-primary-foreground`, `sidebar-accent`, `sidebar-accent-foreground`, `sidebar-border`, `sidebar-ring` |
| Shape | `radius` (base), from which `rounded-sm` to `rounded-4xl` are computed |
| Added by this package | `overlay` (scrim behind modal surfaces), `on-destructive` (text on a solid destructive surface), `slider-thumb` |
| Upstream documentation site only | `surface`, `code`, `selection` and their companions, `destructive-foreground`. No component uses them. |

**Do not use `text-destructive-foreground`.** Its upstream dark value has a contrast of 1.65:1 on `bg-destructive`. Use `text-on-destructive`.

### ThemeProvider and useTheme

`ThemeProvider` (a client component) holds the preference and applies it. Mount it once, near the root.

| Prop | Type | Default | Description |
|---|---|---|---|
| `children` | `React.ReactNode` | none (required) | The application. |
| `defaultTheme` | `"light" \| "dark" \| "system"` | `"system"` | Preference used when nothing is stored. |
| `storageKey` | `string` | `"ui-theme"` | `localStorage` key of the preference. |
| `target` | `HTMLElement \| null` | `document.documentElement` | Element that receives the class `dark`, the attribute `data-theme` and `color-scheme`. |

`useTheme()` returns:

| Field | Type | Meaning |
|---|---|---|
| `theme` | `"light" \| "dark" \| "system"` | The stored preference. |
| `resolvedTheme` | `"light" \| "dark"` | The theme in effect, after `system` is resolved against the operating system. |
| `setTheme` | `(theme) => void` | Changes the preference and stores it. |

```tsx
import { Button, useTheme } from "@boilerplate/ui"

export function DarkModeButton() {
  const { resolvedTheme, setTheme } = useTheme()
  const dark = resolvedTheme === "dark"
  return (
    <Button variant="outline" aria-pressed={dark} onClick={() => setTheme(dark ? "light" : "dark")}>
      Dark mode
    </Button>
  )
}
```

Behaviour to know:

- The stored preference is read after mount, so the first render uses `defaultTheme`. In a server-rendered application put `getThemeScript(storageKey?, defaultTheme?)` in the document head to apply the stored theme before the first paint (`README.md`).
- Every `localStorage` access is wrapped in `try`/`catch`. When storage is blocked or full, the preference lasts for the session only.
- While the preference is `system`, the provider follows the operating system as it changes. A change in another tab of the same application is followed as well.
- Outside a provider, `useTheme()` returns `{ theme: "system", resolvedTheme: "light" }` and a setter that does nothing. Components that read the theme, such as `Toaster`, still render.

## 2. Where to put an override

Write the override in your own stylesheet, after the import of the package stylesheet. Later rules win; the package files stay untouched.

```css
/* app/globals.css */
@import "tailwindcss";
@import "@boilerplate/ui/styles.css";
@import "./brand.css";
```

Override a token in both blocks, `:root` and `.dark`, unless the same value suits both themes. A value set only in `:root` also applies in the dark theme, because `.dark` then has nothing to replace it with.

## 3. Worked example: a brand colour, checked for contrast

The goal is a blue brand colour for the default button, links and the focus ring. The files of this example are in `examples/theming/`.

### Step 1. First attempt

A bright blue with near-white text, the same in both themes (`examples/theming/brand-first-attempt.css`):

```css
:root {
  --primary: oklch(0.7 0.16 262);
  --primary-foreground: oklch(0.985 0 0);
}

.dark {
  --primary: oklch(0.7 0.16 262);
  --primary-foreground: oklch(0.985 0 0);
}
```

### Step 2. Check before adopting

```bash
node scripts/check-contrast.mjs --overlay examples/theming/brand-first-attempt.css --strict
```

Recorded output (lines about the brand colour):

```text
below AA (normal text): light primary-foreground on primary = 2.6:1 (Default button label)
below AA (normal text): light primary on background = 2.72:1 (Link-style button label)
below AA (normal text): dark primary-foreground on primary = 2.6:1 (Default button label)
error: src/theme/tokens.css: light: primary-foreground on primary has contrast 2.6:1, below 4.5:1 (Default button label)
  fix: change --primary-foreground or --primary in the :root block of your theme override (docs/theming.md), then rerun this script
```

The attempt fails: white text on this blue reaches 2.6:1, and the blue as link text on a white page reaches 2.72:1. The Web Content Accessibility Guidelines (WCAG) 2.2, level AA, require 4.5:1 for normal text and 3:1 for large text (at least 24 px, or 18.66 px bold).

### Step 3. Correct the lightness, per theme

On a light page the brand colour must be dark enough to carry white text and to be readable as a link. On a dark page it must be light, and its text dark. Only the lightness and chroma change; the hue stays 262 (`examples/theming/brand.css`):

```css
:root {
  --primary: oklch(0.5 0.2 262);
  --primary-foreground: oklch(0.985 0 0);
  --ring: oklch(0.5 0.2 262);
  --sidebar-primary: oklch(0.5 0.2 262);
  --sidebar-primary-foreground: oklch(0.985 0 0);
}

.dark {
  --primary: oklch(0.72 0.15 262);
  --primary-foreground: oklch(0.2 0.04 262);
  --ring: oklch(0.72 0.15 262);
  --sidebar-primary: oklch(0.72 0.15 262);
  --sidebar-primary-foreground: oklch(0.2 0.04 262);
}
```

### Step 4. Check again

```bash
node scripts/check-contrast.mjs --overlay src/theme/contrast-aa.css,examples/theming/brand.css --strict
```

```text
below AA (normal text): dark destructive-foreground on destructive = 1.78:1 (Upstream pair; unused by components)
contrast: 46 text pairs, 1 below 4.5:1, 1 below 3:1; 7 non-text pairs below 3:1 (informative)
check-contrast: ok
```

The exit code is 0. The computed ratios of the brand pairs:

| Theme | Pair | Ratio | Result |
|---|---|---|---|
| light | `primary-foreground` on `primary` (button label) | 6.00:1 | passes 4.5:1 |
| light | `primary` on `background` (link, focus ring) | 6.27:1 | passes 4.5:1 |
| dark | `primary-foreground` on `primary` | 7.19:1 | passes 4.5:1 |
| dark | `primary` on `background` | 7.85:1 | passes 4.5:1 |

The one remaining line is the upstream token `destructive-foreground`, which no component uses (section 1). The command includes `src/theme/contrast-aa.css` because the default theme itself has combinations below 4.5:1; section 6 explains them. Without that layer the same command reports those upstream combinations and exits with code 1, whatever the brand colour is.

## 4. The radius scale

One variable sets every radius. The steps are multiples of it:

| Class | Value | At the default (0.625 rem = 10 px) |
|---|---|---|
| `rounded-sm` | `--radius` × 0.6 | 6 px |
| `rounded-md` | `--radius` × 0.8 | 8 px |
| `rounded-lg` | `--radius` × 1 | 10 px |
| `rounded-xl` | `--radius` × 1.4 | 14 px |
| `rounded-2xl` | `--radius` × 1.8 | 18 px |
| `rounded-3xl` | `--radius` × 2.2 | 22 px |
| `rounded-4xl` | `--radius` × 2.6 | 26 px |

```css
:root {
  --radius: 0.375rem; /* tighter corners everywhere; 0 gives square corners */
}
```

The radius is the same in both themes, so `:root` is enough. To change one step only, override the mapped variable in a theme block of your own:

```css
@theme inline {
  --radius-md: 0.25rem;
}
```

## 5. Chart colours

`ChartContainer` takes a `config` that maps each data series to a colour. Point the series at the chart tokens, never at a literal:

```tsx
const config = {
  desktop: { label: "Desktop", color: "var(--chart-2)" },
  mobile: { label: "Mobile", color: "var(--chart-4)" },
} satisfies ChartConfig
```

Upstream defines the five chart tokens as references to the Tailwind blue palette (`--chart-1: var(--color-blue-300)` and so on), with the same values in both themes. Override them like any other token, with a separate dark set when the page background changes:

```css
:root {
  --chart-1: oklch(0.8 0.1 262);
  --chart-2: oklch(0.65 0.17 262);
  --chart-3: oklch(0.5 0.2 262);
  --chart-4: oklch(0.6 0.15 200);
  --chart-5: oklch(0.55 0.18 320);
}

.dark {
  --chart-1: oklch(0.85 0.08 262);
  --chart-2: oklch(0.72 0.15 262);
  --chart-3: oklch(0.6 0.19 262);
  --chart-4: oklch(0.7 0.13 200);
  --chart-5: oklch(0.7 0.16 320);
}
```

A chart series is a graphic, not text. WCAG 1.4.11 asks for 3:1 against the adjacent colour. The script reports this as "non-text" and does not fail on it. With the example above, `chart-1` reaches 1.87:1 on a white card and `chart-2` 3.3:1; with the upstream defaults `chart-1` (blue 300) is also below 3:1 on white. Do not rely on a light series colour alone: label the series, or add a pattern or a direct value label. A single series can use two colours per theme through `theme: { light, dark }` in the config.

## 6. Contrast of the default theme

`node scripts/check-contrast.mjs` computes the WCAG 2.2 contrast ratio of every foreground and background pair in both themes and writes `docs/contrast.json`. The full table is in `docs/AUDIT.md`, section 7. Translucent colours are composited over their backdrop before the ratio is computed.

The upstream values are kept unchanged. With them, the following combinations that components use are below 4.5:1 for normal text:

| Theme | Combination | Ratio | Where |
|---|---|---|---|
| light | `text-muted-foreground` on `bg-muted` | 4.34:1 | avatar fallback, keyboard key (`Kbd`) |
| light | `text-destructive/90` on `bg-card` | 4.52:1 computed, 4.49:1 measured in the browser | destructive alert description |
| light | `text-destructive/80` on `bg-card` | 4.12:1 | attachment in the error state |
| light | `text-destructive` on `bg-destructive/10` | 3.99:1 | destructive bubble |
| dark | `text-destructive/80` on `bg-card` | 4.37:1 | attachment in the error state |

All five pass the 3:1 threshold for large text. None was changed silently: the default theme renders exactly as upstream does.

### The optional contrast layer

`src/theme/contrast-aa.css` raises all five above 4.5:1 by changing the lightness of two tokens:

| Token | Theme | Upstream | Contrast layer |
|---|---|---|---|
| `--muted-foreground` | light | `oklch(0.556 0 0)` | `oklch(0.54 0 0)` |
| `--destructive` | light | `oklch(0.577 0.245 27.325)` | `oklch(0.52 0.245 27.325)` |
| `--destructive` | dark | `oklch(0.704 0.191 22.216)` | `oklch(0.74 0.191 22.216)` |

```css
@import "tailwindcss";
@import "@boilerplate/ui/styles.css";
@import "@boilerplate/ui/contrast-aa.css";
@import "./brand.css";
```

With the layer, the automated accessibility scan of the showcase reports no colour-contrast finding in either theme (`docs/VERIFICATION.md`, check 4). The visual difference is small: muted text and the destructive red are slightly darker in the light theme, and the red is slightly lighter in the dark theme.

Use the layer when the product must meet WCAG 2.2 level AA, for example under the European Accessibility Act or the Accessibility for Ontarians with Disabilities Act. Whether a given product falls under such a rule is a legal question that this document does not answer.

### Limits of the check

- The script checks token pairs and the component combinations listed in `scripts/check-contrast.mjs` (`TEXT_PAIRS`). A combination that you introduce in your own code, such as muted text on an accent surface, is not in the list; add it there or rely on the browser scan.
- Automated tools cannot judge text over images or gradients, or whether a colour is the only carrier of meaning.
- The browser scan (`npm run showcase:axe`) measures the rendered page and is the stronger evidence; the script is faster and runs without a browser.

## 7. Checklist for a theme change

1. Write the override in your own stylesheet, in `:root` and `.dark`.
2. Run `node scripts/check-contrast.mjs --overlay src/theme/contrast-aa.css,<your file> --strict`. Exit code 0 is required.
3. Open the showcase (`npm run showcase:dev`) and look at both themes.
4. If the change belongs in the package, follow `skills/theme-system/SKILL.md`.
