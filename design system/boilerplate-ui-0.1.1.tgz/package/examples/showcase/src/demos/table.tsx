import { Badge, Table, TableBody, TableCaption, TableCell, TableFooter, TableHead, TableHeader, TableRow } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Role</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow>
          <TableCell>Ada Lovelace</TableCell>
          <TableCell>Engineer</TableCell>
        </TableRow>
      </TableBody>
    </Table>
  )
}
// #endregion minimal

// #region composed
const invoices = [
  { id: "INV-001", status: "Paid", method: "Card", amount: 250 },
  { id: "INV-002", status: "Pending", method: "Transfer", amount: 150 },
  { id: "INV-003", status: "Overdue", method: "Card", amount: 350 },
]

export function Composed() {
  const total = invoices.reduce((sum, invoice) => sum + invoice.amount, 0)
  return (
    <Table>
      <TableCaption>Invoices issued in March 2026</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead scope="col">Invoice</TableHead>
          <TableHead scope="col">Status</TableHead>
          <TableHead scope="col">Method</TableHead>
          <TableHead scope="col" className="text-right">
            Amount
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {invoices.map((invoice, index) => (
          <TableRow key={invoice.id} data-state={index === 0 ? "selected" : undefined}>
            <TableHead scope="row" className="font-medium">
              {invoice.id}
            </TableHead>
            <TableCell>
              <Badge variant={invoice.status === "Overdue" ? "destructive" : invoice.status === "Paid" ? "secondary" : "outline"}>{invoice.status}</Badge>
            </TableCell>
            <TableCell>{invoice.method}</TableCell>
            <TableCell className="text-right tabular-nums">{invoice.amount.toFixed(2)} EUR</TableCell>
          </TableRow>
        ))}
      </TableBody>
      <TableFooter>
        <TableRow>
          <TableHead scope="row" colSpan={3}>
            Total
          </TableHead>
          <TableCell className="text-right tabular-nums">{total.toFixed(2)} EUR</TableCell>
        </TableRow>
      </TableFooter>
    </Table>
  )
}
// #endregion composed
