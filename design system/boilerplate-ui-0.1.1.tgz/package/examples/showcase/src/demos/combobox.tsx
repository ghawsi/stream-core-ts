import * as React from "react"

import {
  Combobox,
  ComboboxChip,
  ComboboxChips,
  ComboboxChipsInput,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
  ComboboxValue,
  Label,
  useComboboxAnchor,
} from "@boilerplate/ui"

const countries = ["Austria", "Canada", "Germany", "Japan", "Switzerland"]

// #region minimal
export function Minimal() {
  return (
    <div className="grid max-w-xs gap-2">
      <Label htmlFor="combobox-country">Country</Label>
      <Combobox items={countries}>
        <ComboboxInput id="combobox-country" placeholder="Search a country" />
        <ComboboxContent>
          <ComboboxEmpty>No country found.</ComboboxEmpty>
          <ComboboxList>
            {(country: string) => (
              <ComboboxItem key={country} value={country}>
                {country}
              </ComboboxItem>
            )}
          </ComboboxList>
        </ComboboxContent>
      </Combobox>
    </div>
  )
}
// #endregion minimal

// #region composed
const skills = ["ABAP", "TypeScript", "React", "Linux", "PostgreSQL", "Docker"]

export function Composed() {
  const anchor = useComboboxAnchor()
  return (
    <div className="grid max-w-sm gap-2">
      <Label htmlFor="combobox-skills">Skills</Label>
      <Combobox multiple autoHighlight items={skills} defaultValue={["ABAP", "TypeScript"]}>
        <ComboboxChips ref={anchor}>
          <ComboboxValue>
            {(values: string[]) => (
              <React.Fragment>
                {values.map((value) => (
                  <ComboboxChip key={value} aria-label={value}>
                    {value}
                  </ComboboxChip>
                ))}
                <ComboboxChipsInput id="combobox-skills" placeholder="Add a skill" />
              </React.Fragment>
            )}
          </ComboboxValue>
        </ComboboxChips>
        <ComboboxContent anchor={anchor}>
          <ComboboxEmpty>No skill found.</ComboboxEmpty>
          <ComboboxList>
            {(skill: string) => (
              <ComboboxItem key={skill} value={skill}>
                {skill}
              </ComboboxItem>
            )}
          </ComboboxList>
        </ComboboxContent>
      </Combobox>
    </div>
  )
}
// #endregion composed
