import * as React from "react"

import { Label, RadioGroup, RadioGroupItem } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <RadioGroup defaultValue="monthly" aria-label="Billing period">
      <div className="flex items-center gap-2">
        <RadioGroupItem value="monthly" id="radio-group-monthly" />
        <Label htmlFor="radio-group-monthly">Monthly</Label>
      </div>
      <div className="flex items-center gap-2">
        <RadioGroupItem value="yearly" id="radio-group-yearly" />
        <Label htmlFor="radio-group-yearly">Yearly</Label>
      </div>
    </RadioGroup>
  )
}
// #endregion minimal

// #region composed
const plans = [
  { value: "starter", label: "Starter", description: "1 project, community support." },
  { value: "team", label: "Team", description: "10 projects, email support." },
  { value: "enterprise", label: "Enterprise", description: "Contact sales.", disabled: true },
]

export function Composed() {
  const [plan, setPlan] = React.useState("team")
  return (
    <div className="grid max-w-sm gap-3">
      <p id="radio-group-plan-label" className="text-sm font-medium">
        Plan
      </p>
      <RadioGroup value={plan} onValueChange={setPlan} aria-labelledby="radio-group-plan-label">
        {plans.map((item) => (
          <div key={item.value} className="flex items-start gap-3 rounded-md border p-3">
            <RadioGroupItem
              value={item.value}
              id={`radio-group-plan-${item.value}`}
              disabled={item.disabled}
              aria-describedby={`radio-group-plan-${item.value}-description`}
              className="mt-0.5"
            />
            <div className="grid gap-1">
              <Label htmlFor={`radio-group-plan-${item.value}`}>{item.label}</Label>
              <p id={`radio-group-plan-${item.value}-description`} className="text-sm text-muted-foreground">
                {item.description}
              </p>
            </div>
          </div>
        ))}
      </RadioGroup>
      <p className="text-sm text-muted-foreground" aria-live="polite">
        Selected plan: {plan}
      </p>
    </div>
  )
}
// #endregion composed
