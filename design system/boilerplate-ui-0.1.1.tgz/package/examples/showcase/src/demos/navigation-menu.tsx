import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <NavigationMenu aria-label="Minimal navigation">
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuLink href="#navigation-menu" className={navigationMenuTriggerStyle()}>
            Home
          </NavigationMenuLink>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuLink href="#navigation-menu" className={navigationMenuTriggerStyle()}>
            Pricing
          </NavigationMenuLink>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  )
}
// #endregion minimal

// #region composed
const products = [
  { title: "Analytics", description: "Dashboards for traffic and revenue." },
  { title: "Automation", description: "Rules that run on a schedule." },
  { title: "Storage", description: "Files with version history." },
]

export function Composed() {
  return (
    <NavigationMenu aria-label="Site navigation" viewport={false}>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Products</NavigationMenuTrigger>
          <NavigationMenuContent>
            <ul className="grid w-64 gap-1">
              {products.map((product) => (
                <li key={product.title}>
                  <NavigationMenuLink href="#navigation-menu">
                    <span className="font-medium">{product.title}</span>
                    <span className="text-muted-foreground">{product.description}</span>
                  </NavigationMenuLink>
                </li>
              ))}
            </ul>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuLink href="#navigation-menu" className={navigationMenuTriggerStyle()} data-active="true" aria-current="page">
            Documentation
          </NavigationMenuLink>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuLink href="#navigation-menu" className={navigationMenuTriggerStyle()}>
            Support
          </NavigationMenuLink>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  )
}
// #endregion composed
