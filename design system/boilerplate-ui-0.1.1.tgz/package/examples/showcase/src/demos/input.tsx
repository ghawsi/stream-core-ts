import { Input, Label } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="grid gap-2">
      <Label htmlFor="input-name">Name</Label>
      <Input id="input-name" autoComplete="name" />
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid max-w-md gap-4 sm:grid-cols-2">
      <div className="grid gap-2">
        <Label htmlFor="input-email">Email</Label>
        <Input id="input-email" type="email" placeholder="name@example.com" autoComplete="email" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="input-password">Password</Label>
        <Input id="input-password" type="password" autoComplete="new-password" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="input-file">Attachment</Label>
        <Input id="input-file" type="file" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="input-disabled">Disabled</Label>
        <Input id="input-disabled" disabled defaultValue="Cannot be changed" />
      </div>
      <div className="grid gap-2 sm:col-span-2">
        <Label htmlFor="input-invalid">Postal code</Label>
        <Input id="input-invalid" defaultValue="12" aria-invalid="true" aria-describedby="input-invalid-message" />
        <p id="input-invalid-message" className="text-sm text-destructive">
          Enter five digits.
        </p>
      </div>
    </div>
  )
}
// #endregion composed
