import * as React from "react"
import type { DateRange } from "react-day-picker"

import { Calendar } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  const [date, setDate] = React.useState<Date | undefined>(new Date(2026, 0, 15))
  return <Calendar mode="single" selected={date} onSelect={setDate} defaultMonth={new Date(2026, 0, 1)} className="rounded-md border" />
}
// #endregion minimal

// #region composed
export function Composed() {
  const [range, setRange] = React.useState<DateRange | undefined>({
    from: new Date(2026, 1, 9),
    to: new Date(2026, 1, 13),
  })
  return (
    <div className="grid gap-2">
      <Calendar
        mode="range"
        selected={range}
        onSelect={setRange}
        defaultMonth={new Date(2026, 1, 1)}
        captionLayout="dropdown"
        buttonVariant="outline"
        showWeekNumber
        disabled={{ dayOfWeek: [0, 6] }}
        className="rounded-md border"
      />
      <p className="text-sm text-muted-foreground" aria-live="polite">
        {range?.from && range.to
          ? `Selected ${range.from.toLocaleDateString("en-GB")} to ${range.to.toLocaleDateString("en-GB")}`
          : "Select a start and an end date."}
      </p>
    </div>
  )
}
// #endregion composed
