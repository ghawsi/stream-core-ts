import { Button, Spinner } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Spinner />
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-center gap-6">
      <Spinner className="size-6" aria-label="Loading report" />
      <Spinner className="size-8 text-muted-foreground" aria-label="Loading comments" />
      <Button disabled>
        <Spinner aria-hidden="true" />
        Saving
      </Button>
      <p className="flex items-center gap-2 text-sm" role="status">
        <Spinner aria-hidden="true" />
        Synchronising 12 files
      </p>
    </div>
  )
}
// #endregion composed
