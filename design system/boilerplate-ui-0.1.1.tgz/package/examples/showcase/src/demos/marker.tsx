import { CheckIcon } from "lucide-react"

import { Marker, MarkerContent, MarkerIcon } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Marker>
      <MarkerContent>Ada joined the conversation.</MarkerContent>
    </Marker>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid gap-4">
      <Marker variant="default" role="status">
        <MarkerIcon>
          <CheckIcon />
        </MarkerIcon>
        <MarkerContent>The file was saved.</MarkerContent>
      </Marker>
      <Marker variant="separator" role="separator" aria-label="Messages from 12 March">
        <MarkerContent>12 March</MarkerContent>
      </Marker>
      <Marker variant="border">
        <MarkerContent>
          The plan changed to Pro. <a href="#marker">View the invoice</a>
        </MarkerContent>
      </Marker>
    </div>
  )
}
// #endregion composed
