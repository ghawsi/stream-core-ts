import * as React from "react"

import { Checkbox, Label } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="flex items-center gap-2">
      <Checkbox id="checkbox-terms" />
      <Label htmlFor="checkbox-terms">Accept the terms</Label>
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [items, setItems] = React.useState({ email: true, sms: false, push: false })
  const values = Object.values(items)
  const all = values.every(Boolean) ? true : values.some(Boolean) ? "indeterminate" : false

  return (
    <fieldset className="grid gap-3">
      <legend className="mb-2 text-sm font-medium">Notifications</legend>
      <div className="flex items-center gap-2">
        <Checkbox
          id="checkbox-all"
          checked={all}
          onCheckedChange={(checked) => setItems({ email: checked === true, sms: checked === true, push: checked === true })}
        />
        <Label htmlFor="checkbox-all">All channels</Label>
      </div>
      {(Object.keys(items) as Array<keyof typeof items>).map((key) => (
        <div key={key} className="ml-6 flex items-center gap-2">
          <Checkbox id={`checkbox-${key}`} checked={items[key]} onCheckedChange={(checked) => setItems((prev) => ({ ...prev, [key]: checked === true }))} />
          <Label htmlFor={`checkbox-${key}`} className="capitalize">
            {key}
          </Label>
        </div>
      ))}
      <div className="flex items-center gap-2">
        <Checkbox id="checkbox-disabled" disabled />
        <Label htmlFor="checkbox-disabled">Disabled</Label>
      </div>
      <div className="flex items-center gap-2">
        <Checkbox id="checkbox-invalid" aria-invalid="true" aria-describedby="checkbox-invalid-message" />
        <Label htmlFor="checkbox-invalid">Required consent</Label>
        <span id="checkbox-invalid-message" className="text-sm text-destructive">
          Consent is required.
        </span>
      </div>
    </fieldset>
  )
}
// #endregion composed
