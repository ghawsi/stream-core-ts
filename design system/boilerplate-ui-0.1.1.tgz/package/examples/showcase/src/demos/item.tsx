import { ChevronRightIcon, ShieldCheckIcon } from "lucide-react"

import {
  Button,
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemFooter,
  ItemGroup,
  ItemHeader,
  ItemMedia,
  ItemSeparator,
  ItemTitle,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Item variant="outline">
      <ItemContent>
        <ItemTitle>Two-factor authentication</ItemTitle>
        <ItemDescription>Protect the account with a second step.</ItemDescription>
      </ItemContent>
      <ItemActions>
        <Button size="sm" variant="outline">
          Enable
        </Button>
      </ItemActions>
    </Item>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid max-w-lg gap-4">
      <ItemGroup aria-label="Security settings" className="rounded-md border">
        <Item role="listitem" variant="default" size="default">
          <ItemMedia variant="icon">
            <ShieldCheckIcon aria-hidden="true" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Passkeys</ItemTitle>
            <ItemDescription>Sign in with a fingerprint or a security key.</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Button size="sm">Add passkey</Button>
          </ItemActions>
        </Item>
        <ItemSeparator />
        <div role="listitem">
          <Item variant="muted" size="sm" asChild>
            <a href="#item">
              <ItemMedia variant="image">
                <img src="./placeholder.svg" alt="" />
              </ItemMedia>
              <ItemContent>
                <ItemTitle>Active sessions</ItemTitle>
                <ItemDescription>2 devices are signed in.</ItemDescription>
              </ItemContent>
              <ItemActions>
                <ChevronRightIcon className="size-4" aria-hidden="true" />
              </ItemActions>
            </a>
          </Item>
        </div>
      </ItemGroup>

      <Item variant="outline">
        <ItemHeader>Plan</ItemHeader>
        <ItemMedia variant="default">
          <span className="text-2xl font-semibold" aria-hidden="true">
            Pro
          </span>
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Professional</ItemTitle>
          <ItemDescription>10 projects and 50 GB of storage.</ItemDescription>
        </ItemContent>
        <ItemFooter>Renews on 1 March.</ItemFooter>
      </Item>
    </div>
  )
}
// #endregion composed
