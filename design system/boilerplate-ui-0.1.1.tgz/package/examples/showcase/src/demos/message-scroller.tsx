import * as React from "react"

import {
  Bubble,
  BubbleContent,
  Button,
  Message,
  MessageContent,
  MessageHeader,
  MessageScroller,
  MessageScrollerButton,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerProvider,
  MessageScrollerViewport,
  useMessageScroller,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <MessageScrollerProvider>
      <MessageScroller className="h-32 rounded-md border">
        <MessageScrollerViewport aria-label="Short transcript" className="p-3">
          <MessageScrollerContent className="gap-2">
            {["First message", "Second message", "Third message"].map((text) => (
              <MessageScrollerItem key={text}>
                <p className="text-sm">{text}</p>
              </MessageScrollerItem>
            ))}
          </MessageScrollerContent>
        </MessageScrollerViewport>
        <MessageScrollerButton />
      </MessageScroller>
    </MessageScrollerProvider>
  )
}
// #endregion minimal

// #region composed
function Transcript() {
  const [messages, setMessages] = React.useState(() => Array.from({ length: 8 }, (_, index) => `Message ${index + 1}`))
  const { scrollToStart } = useMessageScroller()

  return (
    <div className="grid gap-2">
      <MessageScroller className="h-56 rounded-md border">
        <MessageScrollerViewport aria-label="Support conversation" className="p-3">
          <MessageScrollerContent className="gap-3">
            {messages.map((text, index) => (
              <MessageScrollerItem key={text} messageId={text} scrollAnchor={index === messages.length - 1}>
                <Message align={index % 2 === 0 ? "start" : "end"}>
                  <MessageContent>
                    <MessageHeader className="sr-only">{index % 2 === 0 ? "Support" : "You"}</MessageHeader>
                    <Bubble variant={index % 2 === 0 ? "muted" : "default"} align={index % 2 === 0 ? "start" : "end"}>
                      <BubbleContent>{text}</BubbleContent>
                    </Bubble>
                  </MessageContent>
                </Message>
              </MessageScrollerItem>
            ))}
          </MessageScrollerContent>
        </MessageScrollerViewport>
        <MessageScrollerButton direction="end" />
      </MessageScroller>
      <div className="flex gap-2">
        <Button size="sm" onClick={() => setMessages((list) => [...list, `Message ${list.length + 1}`])}>
          Add message
        </Button>
        <Button size="sm" variant="outline" onClick={() => scrollToStart()}>
          Scroll to start
        </Button>
      </div>
    </div>
  )
}

export function Composed() {
  return (
    <MessageScrollerProvider autoScroll defaultScrollPosition="end">
      <Transcript />
    </MessageScrollerProvider>
  )
}
// #endregion composed
