import { CopyIcon, SearchIcon, SendIcon } from "lucide-react"

import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput, InputGroupText, InputGroupTextarea, Kbd } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <InputGroup>
      <InputGroupInput aria-label="Search" placeholder="Search" />
      <InputGroupAddon>
        <SearchIcon aria-hidden="true" />
      </InputGroupAddon>
    </InputGroup>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid max-w-md gap-4">
      <InputGroup>
        <InputGroupAddon align="inline-start">
          <InputGroupText>https://</InputGroupText>
        </InputGroupAddon>
        <InputGroupInput aria-label="Website" placeholder="example.com" />
        <InputGroupAddon align="inline-end">
          <InputGroupButton size="icon-xs" aria-label="Copy address">
            <CopyIcon />
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>

      <InputGroup>
        <InputGroupInput aria-label="Search documentation" placeholder="Search documentation" />
        <InputGroupAddon align="inline-end">
          <Kbd>⌘K</Kbd>
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">
          <InputGroupButton size="sm" variant="secondary">
            Search
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>

      <InputGroup>
        <InputGroupAddon align="block-start">
          <InputGroupText>Message to support</InputGroupText>
        </InputGroupAddon>
        <InputGroupTextarea aria-label="Message to support" placeholder="Describe the problem" rows={2} />
        <InputGroupAddon align="block-end">
          <InputGroupText className="mr-auto">0 of 500 characters</InputGroupText>
          <InputGroupButton size="xs" variant="outline">
            Attach
          </InputGroupButton>
          <InputGroupButton size="icon-sm" variant="default" aria-label="Send message">
            <SendIcon />
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
    </div>
  )
}
// #endregion composed
