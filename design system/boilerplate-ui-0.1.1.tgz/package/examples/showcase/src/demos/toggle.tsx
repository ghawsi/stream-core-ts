import { BoldIcon, ItalicIcon, UnderlineIcon } from "lucide-react"

import { Toggle } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Toggle aria-label="Bold">
      <BoldIcon />
    </Toggle>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <Toggle variant="default" size="sm" aria-label="Italic (small)">
        <ItalicIcon />
      </Toggle>
      <Toggle variant="default" size="default" defaultPressed aria-label="Bold (default size, pressed)">
        <BoldIcon />
      </Toggle>
      <Toggle variant="outline" size="lg" aria-label="Underline (large, outline)">
        <UnderlineIcon />
      </Toggle>
      <Toggle variant="outline">
        <BoldIcon aria-hidden="true" />
        With text
      </Toggle>
      <Toggle variant="outline" disabled>
        Disabled
      </Toggle>
    </div>
  )
}
// #endregion composed
