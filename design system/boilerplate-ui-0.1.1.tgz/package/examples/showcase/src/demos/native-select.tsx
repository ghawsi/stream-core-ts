import { Label, NativeSelect, NativeSelectOptGroup, NativeSelectOption } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="grid gap-2">
      <Label htmlFor="native-select-language">Language</Label>
      <NativeSelect id="native-select-language" defaultValue="en">
        <NativeSelectOption value="en">English</NativeSelectOption>
        <NativeSelectOption value="de">German</NativeSelectOption>
        <NativeSelectOption value="fa">Persian</NativeSelectOption>
      </NativeSelect>
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-end gap-4">
      <div className="grid gap-2">
        <Label htmlFor="native-select-timezone">Time zone</Label>
        <NativeSelect id="native-select-timezone" size="default" defaultValue="Europe/Berlin">
          <NativeSelectOptGroup label="Europe">
            <NativeSelectOption value="Europe/Berlin">Berlin</NativeSelectOption>
            <NativeSelectOption value="Europe/London">London</NativeSelectOption>
          </NativeSelectOptGroup>
          <NativeSelectOptGroup label="America">
            <NativeSelectOption value="America/Toronto">Toronto</NativeSelectOption>
            <NativeSelectOption value="America/New_York" disabled>
              New York (unavailable)
            </NativeSelectOption>
          </NativeSelectOptGroup>
        </NativeSelect>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="native-select-small">Rows per page</Label>
        <NativeSelect id="native-select-small" size="sm" defaultValue="25">
          <NativeSelectOption value="10">10</NativeSelectOption>
          <NativeSelectOption value="25">25</NativeSelectOption>
          <NativeSelectOption value="50">50</NativeSelectOption>
        </NativeSelect>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="native-select-invalid">Country</Label>
        <NativeSelect id="native-select-invalid" aria-invalid="true" defaultValue="">
          <NativeSelectOption value="" disabled>
            Select a country
          </NativeSelectOption>
          <NativeSelectOption value="ca">Canada</NativeSelectOption>
          <NativeSelectOption value="de">Germany</NativeSelectOption>
        </NativeSelect>
      </div>
    </div>
  )
}
// #endregion composed
