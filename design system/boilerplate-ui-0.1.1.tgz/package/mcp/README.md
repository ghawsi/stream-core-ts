# MCP server

A Model Context Protocol (MCP) server that gives an AI agent read-only access to the component metadata and the design tokens of `@boilerplate/ui`.

## Run

```bash
node mcp/server.mjs
```

The server speaks MCP over standard input and output. It needs `@modelcontextprotocol/sdk` and `zod`, which the package lists as development dependencies; a consumer who installs only the published package runs `npm install` in `mcp/` once.

## Register it with a client

```json
{
  "mcpServers": {
    "boilerplate-ui": {
      "command": "node",
      "args": ["node_modules/@boilerplate/ui/mcp/server.mjs"]
    }
  }
}
```

## Tools

| Tool | Input | Returns |
|---|---|---|
| `list_components` | `category` (optional) | Every component: name, title, description, category, role, exports, documentation path |
| `get_component` | `name` | `metadata/components/<name>.json` and the paths of source, documentation, example and test |
| `get_tokens` | `theme`: `light` (default) or `dark` | `tokens/tokens.json` or `tokens/tokens.dark.json` |
| `search_components` | `query`, `limit` (optional) | Ranked matches by name, role, description, export or category |

Every tool is annotated `readOnlyHint: true`. The server has no write operation. It reads only JSON files inside the package directory, and it checks a component name against the index before it opens a file.

## Verify

```bash
node scripts/mcp-smoke.mjs
```

The script starts the server, lists the tools, calls each one and writes the responses to `docs/evidence/mcp.json`.
