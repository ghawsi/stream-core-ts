#!/usr/bin/env node
// Compute WCAG 2.2 contrast ratios for the token pairs, in both themes.
//
//   node scripts/check-contrast.mjs [--json] [--strict] [--css <file>] [--overlay <file>]
//
// Writes docs/contrast.json (or docs/contrast-aa.json with the contrast layer as overlay).
// Failing pairs are reported, never changed.
// Exit code: 0 when the computation ran; with --strict, 1 when a text pair
// is below the AA threshold for normal text (4.5:1).
// `--css <file>` checks another stylesheet with the same variable names (used by
// docs/theming.md to check a re-themed stylesheet before it is adopted).
// `--overlay <file>[,<file>]` applies the :root and .dark declarations of further
// stylesheets on top, in order (for example src/theme/contrast-aa.css and your brand override).
import { run, writeJson } from "./lib/cli.mjs"
import { composite, contrastRatio, oklchToSrgb, round, srgbToHex } from "./lib/color.mjs"
import { readTokenLayer, resolveValue } from "./lib/css-tokens.mjs"

// [foreground, background, usage]. A background may be `token/NN` (opacity over `background`).
export const TEXT_PAIRS = [
  ["foreground", "background", "Body text"],
  ["card-foreground", "card", "Text on cards"],
  ["popover-foreground", "popover", "Text in popovers, menus and dialogs"],
  ["primary-foreground", "primary", "Default button label"],
  ["secondary-foreground", "secondary", "Secondary button label"],
  ["muted-foreground", "background", "Descriptions and placeholders on the page"],
  ["muted-foreground", "card", "Descriptions on cards"],
  ["muted-foreground", "muted", "Secondary text on muted surfaces (inactive tab, table caption)"],
  ["accent-foreground", "accent", "Hovered menu item, ghost button"],
  ["on-destructive", "destructive", "Destructive button and badge label (light theme surface)"],
  ["on-destructive", "destructive/60", "Destructive button and badge label (dark theme surface: destructive at 60%)"],
  ["destructive", "background", "Error text on the page"],
  ["destructive", "card", "Error text on cards (destructive alert title)"],
  ["destructive/90", "card", "Destructive alert description (text-destructive/90)"],
  ["destructive/80", "card", "Attachment error description (text-destructive/80)"],
  ["destructive", "destructive/10", "Destructive bubble, light theme surface (bg-destructive/10)"],
  ["destructive", "destructive/20", "Destructive bubble, dark theme surface (bg-destructive/20)"],
  ["destructive-foreground", "destructive", "Upstream pair; unused by components"],
  ["primary", "background", "Link-style button label"],
  ["sidebar-foreground", "sidebar", "Sidebar text"],
  ["sidebar-primary-foreground", "sidebar-primary", "Sidebar primary item"],
  ["sidebar-accent-foreground", "sidebar-accent", "Sidebar hovered or active item"],
  ["surface-foreground", "surface", "Upstream documentation-site pair; unused by components"],
  ["code-foreground", "code", "Upstream documentation-site pair; unused by components"],
  ["selection-foreground", "selection", "Upstream documentation-site pair; unused by components"],
]

// Informative only: WCAG 1.4.11 non-text contrast (3:1). Outside the requested scope.
export const NON_TEXT_PAIRS = [
  ["border", "background", "Default border"],
  ["input", "background", "Form control border"],
  ["ring", "background", "Focus ring"],
  ["chart-1", "card", "Chart series 1 on a card"],
  ["chart-2", "card", "Chart series 2 on a card"],
  ["chart-3", "card", "Chart series 3 on a card"],
  ["chart-4", "card", "Chart series 4 on a card"],
  ["chart-5", "card", "Chart series 5 on a card"],
  ["sidebar-border", "sidebar", "Sidebar border"],
]

const AA_NORMAL = 4.5
const AA_LARGE = 3

run("check-contrast", ({ args, report }) => {
  const cssFile = typeof args.flags.css === "string" ? args.flags.css : "src/theme/tokens.css"
  const layer = readTokenLayer(cssFile)
  // One file or a comma-separated list; later files win, as later @import lines do in CSS.
  const overlayFile = typeof args.flags.overlay === "string" ? args.flags.overlay : null
  for (const file of overlayFile ? overlayFile.split(",") : []) {
    const overlay = readTokenLayer(file.trim())
    for (const [name, value] of overlay.light) layer.light.set(name, value)
    for (const [name, value] of overlay.dark) layer.dark.set(name, value)
  }
  const themes = { light: layer.light, dark: new Map([...layer.light, ...layer.dark]) }

  const rgbOf = (spec, scope, backdrop) => {
    const [token, opacity] = spec.split("/")
    const resolved = resolveValue(`--${token}`, scope, layer)
    if (resolved.kind !== "color") return { error: `--${token} does not resolve to a colour (${resolved.kind})` }
    const alpha = resolved.oklch.alpha * (opacity ? Number(opacity) / 100 : 1)
    const rgb = oklchToSrgb(resolved.oklch)
    return { rgb: alpha < 1 ? composite(rgb, alpha, backdrop) : rgb, alpha }
  }

  const compute = (pairs, theme, scope, kind) =>
    pairs.map(([fg, bg, usage]) => {
      const page = rgbOf("background", scope, [1, 1, 1])
      const back = rgbOf(bg, scope, page.rgb ?? [1, 1, 1])
      const front = back.rgb ? rgbOf(fg, scope, back.rgb) : { error: back.error }
      if (back.error || front.error) {
        report.fail({
          file: cssFile,
          problem: `${theme}: cannot compute ${fg} on ${bg}: ${back.error ?? front.error}`,
          fix: `define the variable in the :root and .dark blocks of ${cssFile}`,
        })
        return { theme, kind, foreground: fg, background: bg, usage, error: back.error ?? front.error }
      }
      const ratio = round(contrastRatio(front.rgb, back.rgb), 2)
      return {
        theme,
        kind,
        foreground: fg,
        background: bg,
        usage,
        foregroundHex: srgbToHex(front.rgb),
        backgroundHex: srgbToHex(back.rgb),
        ratio,
        ...(kind === "text"
          ? { aaNormalText: ratio >= AA_NORMAL, aaLargeText: ratio >= AA_LARGE }
          : { nonText3to1: ratio >= AA_LARGE }),
      }
    })

  const results = []
  for (const [theme, scope] of Object.entries(themes)) {
    results.push(...compute(TEXT_PAIRS, theme, scope, "text"), ...compute(NON_TEXT_PAIRS, theme, scope, "non-text"))
  }

  // Some surfaces exist in one theme only: destructive at 60% (button) and at 20% (bubble) in the
  // dark theme; the solid destructive button surface and destructive at 10% in the light theme.
  const relevant = results.filter(
    (r) =>
      !(r.background === "destructive/60" && r.theme === "light") &&
      !(r.foreground === "on-destructive" && r.background === "destructive" && r.theme === "dark") &&
      !(r.background === "destructive/10" && r.theme === "dark") &&
      !(r.background === "destructive/20" && r.theme === "light"),
  )
  const text = relevant.filter((r) => r.kind === "text" && !r.error)
  const failNormal = text.filter((r) => !r.aaNormalText)
  const failLarge = text.filter((r) => !r.aaLargeText)
  const nonTextFail = relevant.filter((r) => r.kind === "non-text" && !r.error && !r.nonText3to1)

  const summary = {
    source: cssFile,
    overlay: overlayFile,
    thresholds: { aaNormalText: AA_NORMAL, aaLargeText: AA_LARGE, nonText: AA_LARGE },
    method:
      "OKLCH to sRGB (CSS Color 4), translucent colours composited over their backdrop in gamma-encoded sRGB, WCAG 2.2 relative luminance and contrast ratio.",
    textPairsChecked: text.length,
    textPairsBelowAaNormal: failNormal.length,
    textPairsBelowAaLarge: failLarge.length,
    nonTextPairsBelow3to1: nonTextFail.length,
  }
  if (cssFile === "src/theme/tokens.css" && !overlayFile) writeJson("docs/contrast.json", { summary, results: relevant })
  if (cssFile === "src/theme/tokens.css" && overlayFile === "src/theme/contrast-aa.css") writeJson("docs/contrast-aa.json", { summary, results: relevant })

  for (const r of failNormal) {
    report.info(`below AA (normal text): ${r.theme} ${r.foreground} on ${r.background} = ${r.ratio}:1 (${r.usage})`)
  }
  report.info(`contrast: ${text.length} text pairs, ${failNormal.length} below 4.5:1, ${failLarge.length} below 3:1; ${nonTextFail.length} non-text pairs below 3:1 (informative)`)

  if (args.flags.strict === true) {
    // Pairs that no component uses are reported above but do not fail the strict run.
    for (const r of failNormal.filter((x) => !x.usage.includes("unused by components"))) {
      report.fail({
        file: cssFile,
        problem: `${r.theme}: ${r.foreground} on ${r.background} has contrast ${r.ratio}:1, below 4.5:1 (${r.usage})`,
        fix: `change --${r.foreground.split("/")[0]} or --${r.background.split("/")[0]} in the ${r.theme === "dark" ? ".dark" : ":root"} block of your theme override (docs/theming.md), then rerun this script`,
      })
    }
  }
  return { summary, failing: failNormal, nonTextFailing: nonTextFail, results: relevant }
})
