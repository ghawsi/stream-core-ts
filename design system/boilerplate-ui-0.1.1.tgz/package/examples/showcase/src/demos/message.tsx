import { Avatar, AvatarFallback, Bubble, BubbleContent, Message, MessageAvatar, MessageContent, MessageFooter, MessageGroup, MessageHeader } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Message>
      <MessageContent>
        <MessageHeader>Ada</MessageHeader>
        <Bubble variant="muted">
          <BubbleContent>The deployment is complete.</BubbleContent>
        </Bubble>
      </MessageContent>
    </Message>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <MessageGroup role="log" aria-label="Conversation with Ada" className="max-w-lg gap-6">
      <Message align="start">
        <MessageAvatar>
          <Avatar size="sm">
            <AvatarFallback>AL</AvatarFallback>
          </Avatar>
        </MessageAvatar>
        <MessageContent>
          <MessageHeader>Ada Lovelace</MessageHeader>
          <Bubble variant="muted">
            <BubbleContent>Can you review the pull request today?</BubbleContent>
          </Bubble>
          <MessageFooter>
            <time dateTime="2026-03-12T09:41">09:41</time>
          </MessageFooter>
        </MessageContent>
      </Message>
      <Message align="end">
        <MessageContent>
          <MessageHeader className="sr-only">You</MessageHeader>
          <Bubble align="end">
            <BubbleContent>Yes. I will finish it before noon.</BubbleContent>
          </Bubble>
          <MessageFooter>
            <time dateTime="2026-03-12T09:43">09:43</time>
            <span className="ml-1">· Read</span>
          </MessageFooter>
        </MessageContent>
      </Message>
    </MessageGroup>
  )
}
// #endregion composed
