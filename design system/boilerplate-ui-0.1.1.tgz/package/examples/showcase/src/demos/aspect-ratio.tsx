import { AspectRatio } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <AspectRatio ratio={16 / 9} className="rounded-md bg-muted">
      <img src="./placeholder.svg" alt="Placeholder landscape" className="size-full rounded-md object-cover" />
    </AspectRatio>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid grid-cols-3 gap-3">
      {[
        { label: "1 : 1", ratio: 1 },
        { label: "4 : 3", ratio: 4 / 3 },
        { label: "16 : 9", ratio: 16 / 9 },
      ].map(({ label, ratio }) => (
        <figure key={label} className="space-y-1">
          <AspectRatio ratio={ratio} className="rounded-md bg-muted">
            <img src="./placeholder.svg" alt={`Placeholder at ratio ${label}`} className="size-full rounded-md object-cover" />
          </AspectRatio>
          <figcaption className="text-xs text-muted-foreground">{label}</figcaption>
        </figure>
      ))}
    </div>
  )
}
// #endregion composed
