import { Bar, BarChart, CartesianGrid, Line, LineChart, XAxis } from "recharts"

import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@boilerplate/ui"

const data = [
  { month: "Jan", desktop: 186, mobile: 80 },
  { month: "Feb", desktop: 305, mobile: 200 },
  { month: "Mar", desktop: 237, mobile: 120 },
  { month: "Apr", desktop: 173, mobile: 190 },
  { month: "May", desktop: 209, mobile: 130 },
  { month: "Jun", desktop: 214, mobile: 140 },
]

// Series colours come from the chart tokens, never from literals.
const config = {
  desktop: { label: "Desktop", color: "var(--chart-2)" },
  mobile: { label: "Mobile", color: "var(--chart-4)" },
} satisfies ChartConfig

// #region minimal
export function Minimal() {
  return (
    <ChartContainer config={config} className="aspect-auto h-40 w-full" role="img" aria-label="Bar chart of desktop visits per month, January to June">
      <BarChart data={data}>
        <XAxis dataKey="month" tickLine={false} axisLine={false} />
        <Bar dataKey="desktop" fill="var(--color-desktop)" radius={4} isAnimationActive={false} />
      </BarChart>
    </ChartContainer>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <figure className="grid grid-cols-1 gap-2">
      <ChartContainer config={config} className="aspect-auto h-56 w-full">
        <LineChart accessibilityLayer data={data} margin={{ left: 12, right: 12 }}>
          <CartesianGrid vertical={false} />
          <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
          <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
          <ChartLegend content={<ChartLegendContent />} />
          <Line dataKey="desktop" type="monotone" stroke="var(--color-desktop)" strokeWidth={2} dot={false} isAnimationActive={false} />
          <Line dataKey="mobile" type="monotone" stroke="var(--color-mobile)" strokeWidth={2} dot={false} isAnimationActive={false} />
        </LineChart>
      </ChartContainer>
      <figcaption className="text-sm text-muted-foreground">
        Visits per month by device. Desktop peaked in February (305); mobile peaked in February (200).
      </figcaption>
      {/* The tooltip indicator has three styles: dot (default), line and dashed. */}
      <ChartContainer config={config} className="aspect-auto h-40 w-full" role="img" aria-label="Bar chart of mobile visits per month, January to June">
        <BarChart data={data}>
          <XAxis dataKey="month" tickLine={false} axisLine={false} />
          <ChartTooltip content={<ChartTooltipContent indicator="dashed" />} />
          <Bar dataKey="mobile" fill="var(--color-mobile)" radius={4} isAnimationActive={false} />
        </BarChart>
      </ChartContainer>
    </figure>
  )
}
// #endregion composed
