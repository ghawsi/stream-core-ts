import {
  Checkbox,
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldTitle,
  Input,
  Switch,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Field>
      <FieldLabel htmlFor="field-email">Email</FieldLabel>
      <Input id="field-email" type="email" autoComplete="email" aria-describedby="field-email-description" />
      <FieldDescription id="field-email-description">Used for sign-in and receipts.</FieldDescription>
    </Field>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <form className="max-w-md" onSubmit={(event) => event.preventDefault()}>
      <FieldGroup>
        <FieldSet>
          <FieldLegend variant="legend">Account</FieldLegend>
          <Field orientation="vertical" data-invalid="true">
            <FieldLabel htmlFor="field-username">Username</FieldLabel>
            <Input id="field-username" defaultValue="ada lovelace" aria-invalid="true" aria-describedby="field-username-error" />
            <FieldError id="field-username-error" errors={[{ message: "The username cannot contain spaces." }]} />
          </Field>
        </FieldSet>

        <FieldSeparator>Preferences</FieldSeparator>

        <FieldSet>
          <FieldLegend variant="label">Notifications</FieldLegend>
          <Field orientation="horizontal">
            <Checkbox id="field-news" defaultChecked />
            <FieldContent>
              <FieldLabel htmlFor="field-news">Product news</FieldLabel>
              <FieldDescription>One email per month.</FieldDescription>
            </FieldContent>
          </Field>
          <Field orientation="responsive">
            <FieldContent>
              <FieldTitle id="field-digest-title">Weekly digest</FieldTitle>
              <FieldDescription>A summary of activity every Monday.</FieldDescription>
            </FieldContent>
            <Switch id="field-digest" aria-labelledby="field-digest-title" />
          </Field>
        </FieldSet>
      </FieldGroup>
    </form>
  )
}
// #endregion composed
