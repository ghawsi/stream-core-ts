import { Button, Kbd, KbdGroup } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <p className="text-sm">
      Press <Kbd>Esc</Kbd> to close.
    </p>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-center gap-4 text-sm">
      <span>
        Save:{" "}
        <KbdGroup>
          <Kbd>Ctrl</Kbd>
          <span aria-hidden="true">+</span>
          <Kbd>S</Kbd>
        </KbdGroup>
      </span>
      <span>
        Command palette:{" "}
        <KbdGroup>
          <Kbd>⌘</Kbd>
          <Kbd>K</Kbd>
        </KbdGroup>
      </span>
      <Button variant="outline" size="sm" aria-keyshortcuts="Control+Enter">
        Send <Kbd>Ctrl ⏎</Kbd>
      </Button>
    </div>
  )
}
// #endregion composed
