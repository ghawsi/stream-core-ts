import { Avatar, AvatarFallback, Button, HoverCard, HoverCardContent, HoverCardTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <HoverCard>
      <HoverCardTrigger asChild>
        <a href="#hover-card" className="text-sm underline underline-offset-4">
          Hover for details
        </a>
      </HoverCardTrigger>
      <HoverCardContent>Supplementary details that are also available on the linked page.</HoverCardContent>
    </HoverCard>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <HoverCard openDelay={100} closeDelay={100}>
      <HoverCardTrigger asChild>
        <Button variant="link" asChild>
          <a href="#hover-card">@ada</a>
        </Button>
      </HoverCardTrigger>
      <HoverCardContent className="w-72" align="start">
        <div className="flex gap-3">
          <Avatar>
            <AvatarFallback>AL</AvatarFallback>
          </Avatar>
          <div className="grid gap-1">
            <p className="text-sm font-semibold">Ada Lovelace</p>
            <p className="text-sm">Wrote the first published algorithm for a machine.</p>
            <p className="text-xs text-muted-foreground">Joined December 1842</p>
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  )
}
// #endregion composed
