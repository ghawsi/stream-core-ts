import { FileTextIcon, ImageIcon, UploadIcon, XIcon } from "lucide-react"

import {
  Attachment,
  AttachmentAction,
  AttachmentActions,
  AttachmentContent,
  AttachmentDescription,
  AttachmentGroup,
  AttachmentMedia,
  AttachmentTitle,
  AttachmentTrigger,
  Spinner,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Attachment>
      <AttachmentMedia>
        <FileTextIcon aria-hidden="true" />
      </AttachmentMedia>
      <AttachmentContent>
        <AttachmentTitle>report.pdf</AttachmentTitle>
        <AttachmentDescription>240 KB</AttachmentDescription>
      </AttachmentContent>
    </Attachment>
  )
}
// #endregion minimal

// #region composed
const states = [
  { state: "idle", title: "Add a file", description: "PDF or PNG, up to 10 MB" },
  { state: "uploading", title: "contract.pdf", description: "Uploading, 42%" },
  { state: "processing", title: "scan.png", description: "Processing" },
  { state: "error", title: "archive.zip", description: "File type not allowed" },
  { state: "done", title: "invoice.pdf", description: "88 KB" },
] as const

export function Composed() {
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap gap-3">
        {states.map(({ state, title, description }) => (
          <Attachment key={state} state={state} size="default" orientation="horizontal">
            <AttachmentMedia variant="icon">
              {state === "uploading" || state === "processing" ? (
                <Spinner aria-label={description} />
              ) : state === "idle" ? (
                <UploadIcon aria-hidden="true" />
              ) : (
                <FileTextIcon aria-hidden="true" />
              )}
            </AttachmentMedia>
            <AttachmentContent>
              <AttachmentTitle>{title}</AttachmentTitle>
              <AttachmentDescription>{description}</AttachmentDescription>
            </AttachmentContent>
            {state === "idle" ? (
              <AttachmentTrigger aria-label="Choose a file to attach" />
            ) : (
              <AttachmentActions>
                <AttachmentAction aria-label={`Remove ${title}`}>
                  <XIcon />
                </AttachmentAction>
              </AttachmentActions>
            )}
          </Attachment>
        ))}
      </div>

      <AttachmentGroup aria-label="Attached images" role="group">
        <Attachment size="sm">
          <AttachmentMedia variant="image">
            <img src="./placeholder.svg" alt="" />
          </AttachmentMedia>
          <AttachmentContent>
            <AttachmentTitle>photo-small.png</AttachmentTitle>
            <AttachmentDescription>Size sm</AttachmentDescription>
          </AttachmentContent>
        </Attachment>
        <Attachment size="xs">
          <AttachmentMedia variant="icon">
            <ImageIcon aria-hidden="true" />
          </AttachmentMedia>
          <AttachmentContent>
            <AttachmentTitle>photo-xs.png</AttachmentTitle>
          </AttachmentContent>
        </Attachment>
        <Attachment orientation="vertical">
          <AttachmentMedia variant="image">
            <img src="./placeholder.svg" alt="" />
          </AttachmentMedia>
          <AttachmentContent>
            <AttachmentTitle>vertical.png</AttachmentTitle>
            <AttachmentDescription>1.2 MB</AttachmentDescription>
          </AttachmentContent>
        </Attachment>
      </AttachmentGroup>
    </div>
  )
}
// #endregion composed
