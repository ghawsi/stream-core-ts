# AGENTS.md

Instructions for AI coding agents that work in this repository or write code with `@boilerplate/ui`. People can read `README.md` instead; the facts are the same.

`@boilerplate/ui` is a React 19 design system: 61 components ported from shadcn/ui (style `new-york-v4`), built on Radix UI primitives, TypeScript in strict mode and Tailwind CSS v4.

## Find information

| Need | Read |
|---|---|
| Which components exist | `metadata/components.json` (index) or `llms.txt` |
| Props, variants, slots, accessibility of one component | `metadata/components/<name>.json` (data) or `docs/components/<name>.md` (prose and examples) |
| A working example | `examples/showcase/src/demos/<name>.tsx` (type-checked, rendered and tested) |
| Tokens and theming | `docs/theming.md`, `src/theme/tokens.css`, `tokens/tokens.json` |
| What differs from upstream shadcn/ui | `CHANGELOG.md` |
| What was verified, and how | `docs/VERIFICATION.md` |

The installed package (`node_modules/@boilerplate/ui`) contains `src/`, `dist/`, `docs/`, `metadata/`, `tokens/`, `skills/`, `mcp/`, `public/r/` and the example files in `examples/showcase/src/demos/`. The tests, the evaluation tasks, the showcase application and most scripts exist only in the repository; paths to them in the metadata (`test`) refer to the repository.

## Setup

```bash
npm install          # Node.js 20.19 or later
```

No environment variables, no interactive steps. The browser checks need an installed Chrome or Chromium; set `CHROME_PATH` if it is not in a standard location.

## Test

```bash
npm run typecheck        # tsc --noEmit, must report zero errors
npm run lint             # eslint ., must report zero errors and zero warnings
npm test                 # Vitest and Testing Library, every component
npm run test:coverage    # the same with coverage; fails below 80% of lines in src/components/ui
npx vitest run tests/components/button.test.tsx   # one component
```

A full test run takes about four minutes because every test file loads the whole package. Run the single file while you work and the full suite before you finish.

## Build

```bash
npm run generate         # index, tokens, metadata, registry and docs from the sources
npm run build            # dist/: one module per source file, with declarations
npm run verify           # every check below, written to docs/VERIFICATION.md
```

Other checks, each runnable alone:

```bash
npm run check:hardcoded  # no colour, radius or font-size literal in a component
npm run check:contrast   # WCAG contrast of the token pairs, both themes
npm run validate         # tokens, registry, metadata, documents against their schemas
npm run showcase:build && npm run showcase:axe && npm run showcase:screenshots
npm run mcp:smoke        # start the MCP server and call every tool
```

## Showcase

```bash
npm run showcase:dev     # http://localhost:5173, every component in both themes
npm run showcase:build   # static build in examples/showcase/dist
```

`?theme=dark` or `?theme=light` forces a theme. `?contrast=aa` adds the optional contrast layer. The showcase renders `Minimal` and `Composed` from each file in `examples/showcase/src/demos/`.

## Code conventions

1. **Import from the package root**: `import { Button, cn } from "@boilerplate/ui"`. Inside `src/`, import siblings through the `@/` alias (`@/components/ui/button`).
2. **Merge classes with `cn()`**, never with string concatenation. `className` from the caller goes last, so that it wins.
3. **Semantic tokens only.** Use `bg-primary`, `text-muted-foreground`, `border-border`, `rounded-md`, `text-sm`. Do not write colour literals (`#fff`, `rgb()`, `oklch()`), palette classes (`bg-red-500`, `text-white`, `bg-black/50`), arbitrary radii (`rounded-[4px]`) or arbitrary font sizes (`text-[13px]`). `npm run check:hardcoded` fails on them.
4. **Text on a destructive surface is `text-on-destructive`.** Do not use `text-destructive-foreground`: the upstream dark value of that token is unreadable on `bg-destructive` (1.65:1).
5. **Every interactive element has an accessible name.** An icon-only button must have `aria-label`. Agents and screen readers read the page through the accessibility tree; an unnamed control is invisible to both.
6. **Keep the selectors stable.** Every part writes `data-slot`. Components with a `variant` or `size` prop write `data-variant` and `data-size`. Radix writes `data-state`. Tests and agents select by these attributes and by role and name, never by class. A part rendered with `asChild` gives its `data-slot` to the child: a `Button` inside `DialogTrigger asChild` carries `data-slot="dialog-trigger"`.
7. **Preserve composition.** Parts take `React.ComponentProps<...>`, spread the remaining props onto the rendered element (this forwards `ref` in React 19) and support `asChild` where upstream does.
8. **`"use client"` only where the source has it.** Do not add it to presentational components (`card`, `badge`, `button`, ...).
9. **TypeScript strict, no `any`.** ESLint fails on `any`.
10. **Motion.** CSS animations are shortened by the `prefers-reduced-motion` rule in `src/theme/styles.css`. For motion driven by JavaScript, call `prefersReducedMotion()` from `@/lib/motion`.
11. **Writing.** British spelling in prose (colour, behaviour). Plain statements, no marketing language.

## Required providers

A component that needs a provider fails or misbehaves without it. The same list is in each component's metadata under `dependencies.providers`.

| Provider | Needed by | Without it |
|---|---|---|
| `TooltipProvider` | `Tooltip` | Throws. Mount one near the root. `SidebarProvider` already contains one. |
| `SidebarProvider` | every `Sidebar*` component, `useSidebar()` | Throws. |
| `Form` (react-hook-form `FormProvider`) | `FormField`, `FormItem`, `FormLabel`, `FormControl`, `FormDescription`, `FormMessage` | Throws or loses the field state. |
| `Toaster` | `toast()` from `sonner` | Nothing is shown. Mount one `Toaster`. |
| `ThemeProvider` | optional: `useTheme()`, `Toaster` | Light theme; `Toaster` follows the operating system. |
| `MessageScrollerProvider` | `MessageScroller*`, `useMessageScroller()` | Throws. |
| `DirectionProvider` | optional: right-to-left layouts | Left-to-right. |

Minimal application root:

```tsx
import { ThemeProvider, Toaster, TooltipProvider } from "@boilerplate/ui"

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <TooltipProvider>
        {children}
        <Toaster />
      </TooltipProvider>
    </ThemeProvider>
  )
}
```

No component reads any other global state.

## Add a component

Follow `skills/add-component/SKILL.md`. In short:

1. Add `src/components/ui/<name>.tsx` (conventions above; `data-slot` on every part).
2. Add `examples/showcase/src/demos/<name>.tsx` with `Minimal` and `Composed` inside `// #region minimal` and `// #region composed` markers; show every variant value.
3. Add `tests/components/<name>.test.tsx` with `componentSuite()` from `tests/helpers.tsx`: one render test and one interaction test.
4. Add the entry to `scripts/data/components.info.json` (purpose, category, role, keyboard) and any missing prop description to `scripts/data/prop-descriptions.json`.
5. Run `npm run generate`, then `npm run typecheck && npm run lint && npx vitest run tests/components/<name>.test.tsx && npm run check:hardcoded && npm run validate`.
6. Record the addition in `scripts/build-changelog.mjs` and regenerate `CHANGELOG.md`.

To change an upstream component, add an entry to `scripts/deviations.mjs` and run `npm run port`; do not edit the file under `src/components/ui/` by hand, because the next port overwrites it.

## Do not change

- `LICENSE.md` and the attribution to shadcn (MIT License, Copyright (c) 2023 shadcn). Keep the notice in every copy.
- **Token names.** `--background`, `--primary`, `--radius` and the others are a public interface: applications override them. Add tokens; do not rename or remove them.
- **Token values in `src/theme/tokens.css`**, section 1. They are the upstream values. Re-theme by overriding in your own stylesheet (`docs/theming.md`).
- **`data-slot` values and exported names.** Changing one is a breaking change (`CHANGELOG.md`, versioning rules).
- **Generated files**, by hand: `src/index.ts`, `src/theme/tokens.css`, `src/theme/tokens.ts`, `src/theme/shadcn-tailwind.css`, `src/components/ui/*.tsx` (ported), `manifest.json`, `tokens/*.json`, `metadata/**`, `registry.json`, `public/r/**`, `docs/components/**`, `docs/AUDIT.md`, `docs/VERIFICATION.md`, `llms.txt`, `CHANGELOG.md`. Change the generator or its input and rerun it. Each file names its generator in its first lines.
- **Radix UI.** Do not replace a primitive with another library.

## MCP server

A Model Context Protocol (MCP) server gives read-only access to the metadata and the tokens.

```bash
node mcp/server.mjs      # standard input and output transport
```

```json
{ "mcpServers": { "boilerplate-ui": { "command": "node", "args": ["mcp/server.mjs"] } } }
```

| Tool | Input | Returns |
|---|---|---|
| `list_components` | `category` (optional) | name, title, description, category, role, exports, documentation path of every component |
| `get_component` | `name` | `metadata/components/<name>.json` and the paths of source, documentation, example and test |
| `get_tokens` | `theme`: `light` (default) or `dark` | `tokens/tokens.json` or `tokens/tokens.dark.json` |
| `search_components` | `query`, `limit` (optional) | ranked matches by name, role, description, export or category |

The server has no write operation. `npm run mcp:smoke` calls every tool and records the responses in `docs/evidence/mcp.json`.

The components are also published as a shadcn registry (`registry.json`, items in `public/r/`). Once the directory is served over HTTP, add `"registries": { "@boilerplate": "https://<host>/r/{name}.json" }` to `components.json`; the shadcn command-line tool and the shadcn MCP server can then list, search, view and install `@boilerplate/<name>`. Install `@boilerplate/theme` first.

## Tooling contract

Every script in `scripts/` follows the same rules, so that an agent can run it and act on the result:

- It never prompts and reads no standard input.
- `--json` prints one JSON object on standard output and nothing else: `{ "script", "ok", "errors": [{ "file", "problem", "fix" }], "warnings", "data" }`.
- The exit code is 0 on success and 1 on failure.
- Every error names the file and the fix.

## Versioning and deprecation

Semantic Versioning. A deprecated prop or component keeps working until the next major version; it carries an `@deprecated` JSDoc tag that names the replacement, a `deprecated` object in its metadata file and an entry in `CHANGELOG.md`.
