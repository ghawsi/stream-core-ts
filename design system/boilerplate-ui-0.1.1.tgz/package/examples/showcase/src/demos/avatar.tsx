import { Avatar, AvatarBadge, AvatarFallback, AvatarGroup, AvatarGroupCount, AvatarImage } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Avatar>
      <AvatarImage src="./placeholder.svg" alt="Ada Lovelace" />
      <AvatarFallback>AL</AvatarFallback>
    </Avatar>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-center gap-6">
      <div className="flex items-center gap-3">
        <Avatar size="sm">
          <AvatarFallback>SM</AvatarFallback>
        </Avatar>
        <Avatar size="default">
          <AvatarFallback>MD</AvatarFallback>
        </Avatar>
        <Avatar size="lg">
          <AvatarImage src="./placeholder.svg" alt="Grace Hopper" />
          <AvatarFallback>GH</AvatarFallback>
          <AvatarBadge aria-label="Online" role="img" />
        </Avatar>
      </div>

      <AvatarGroup aria-label="Project members" role="group">
        <Avatar>
          <AvatarFallback>AL</AvatarFallback>
        </Avatar>
        <Avatar>
          <AvatarFallback>GH</AvatarFallback>
        </Avatar>
        <Avatar>
          <AvatarFallback>KJ</AvatarFallback>
        </Avatar>
        <AvatarGroupCount aria-label="3 more members">+3</AvatarGroupCount>
      </AvatarGroup>
    </div>
  )
}
// #endregion composed
