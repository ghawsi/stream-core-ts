import { FolderIcon, HomeIcon, InboxIcon, MoreHorizontalIcon, PlusIcon, SettingsIcon } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
} from "@boilerplate/ui"

// The sidebar is positioned against the viewport by default. Inside a page
// section, `relative` on the provider and `absolute h-full` on the sidebar
// keep it within its box.
const boxed = "relative h-72 min-h-0 overflow-hidden rounded-md border"

// #region minimal
export function Minimal() {
  return (
    <SidebarProvider className={boxed}>
      <Sidebar collapsible="none" aria-label="Minimal sidebar" role="navigation">
        <SidebarContent>
          <SidebarMenu className="p-2">
            <SidebarMenuItem>
              <SidebarMenuButton isActive>Home</SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton>Inbox</SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>
      </Sidebar>
    </SidebarProvider>
  )
}
// #endregion minimal

// #region composed
function Navigation() {
  return (
    <>
      <SidebarHeader>
        <SidebarInput aria-label="Search the workspace" placeholder="Search" />
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Workspace</SidebarGroupLabel>
          <SidebarGroupAction aria-label="Add project">
            <PlusIcon />
          </SidebarGroupAction>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton isActive tooltip="Home" variant="default" size="default">
                  <HomeIcon aria-hidden="true" />
                  <span>Home</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Inbox" asChild>
                  <a href="#sidebar">
                    <InboxIcon aria-hidden="true" />
                    <span>Inbox</span>
                  </a>
                </SidebarMenuButton>
                <SidebarMenuBadge>4</SidebarMenuBadge>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Projects">
                  <FolderIcon aria-hidden="true" />
                  <span>Projects</span>
                </SidebarMenuButton>
                <SidebarMenuAction showOnHover aria-label="Project options">
                  <MoreHorizontalIcon />
                </SidebarMenuAction>
                <SidebarMenuSub>
                  <SidebarMenuSubItem>
                    <SidebarMenuSubButton href="#sidebar" size="md" isActive>
                      Design system
                    </SidebarMenuSubButton>
                  </SidebarMenuSubItem>
                  <SidebarMenuSubItem>
                    <SidebarMenuSubButton href="#sidebar" size="sm">
                      Website
                    </SidebarMenuSubButton>
                  </SidebarMenuSubItem>
                </SidebarMenuSub>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarSeparator />
        <SidebarGroup>
          <SidebarGroupLabel>Sizes and variants</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton size="sm" variant="outline">
                  Small, outline
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton size="lg">Large</SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem aria-hidden="true">
                <SidebarMenuSkeleton showIcon />
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton tooltip="Settings">
              <SettingsIcon aria-hidden="true" />
              <span>Settings</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </>
  )
}

const layouts = [
  { variant: "sidebar", side: "left", collapsible: "icon" },
  { variant: "floating", side: "right", collapsible: "offcanvas" },
  { variant: "inset", side: "left", collapsible: "offcanvas" },
] as const

export function Composed() {
  return (
    <div className="grid gap-4">
      {layouts.map(({ variant, side, collapsible }) => (
        <SidebarProvider key={variant} className={boxed} style={{ "--sidebar-width": "14rem" } as React.CSSProperties}>
          <Sidebar variant={variant} side={side} collapsible={collapsible} className="absolute h-full" aria-label={`Sidebar, variant ${variant}`}>
            <Navigation />
            <SidebarRail />
          </Sidebar>
          <SidebarInset role="region" aria-label={`Content beside the ${variant} sidebar`} className="min-h-0">
            <header className="flex h-12 items-center gap-2 border-b px-3">
              <SidebarTrigger />
              <span className="text-sm font-medium">
                variant {variant}, side {side}, collapsible {collapsible}
              </span>
            </header>
            <p className="p-3 text-sm text-muted-foreground">Press the button, or Ctrl+B, to toggle the sidebar. Below 768 px the sidebar opens as a sheet.</p>
          </SidebarInset>
        </SidebarProvider>
      ))}
    </div>
  )
}
// #endregion composed
