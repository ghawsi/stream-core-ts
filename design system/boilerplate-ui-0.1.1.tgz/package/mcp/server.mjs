#!/usr/bin/env node
// Model Context Protocol (MCP) server of @boilerplate/ui.
//
//   node mcp/server.mjs            (standard input and output transport)
//
// It exposes four read-only tools over the files that ship with the package:
//   list_components     the component index, optionally filtered by category
//   get_component       metadata/components/<name>.json and the paths of source, docs, example and test
//   get_tokens          tokens/tokens.json (light) or tokens/tokens.dark.json (dark overrides)
//   search_components   search by name, role, description, export or category
//
// There is no write operation: the server only reads JSON files below its own
// package directory, and component names are checked against the index before
// any file is opened.
import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js"
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js"
import { z } from "zod"

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
const readJson = (file) => JSON.parse(fs.readFileSync(path.join(ROOT, file), "utf8"))
const pkg = readJson("package.json")

function loadIndex() {
  return readJson("metadata/components.json")
}

function reply(result) {
  return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }], structuredContent: result }
}

function failure(message, extra = {}) {
  return { isError: true, content: [{ type: "text", text: JSON.stringify({ error: message, ...extra }, null, 2) }] }
}

const brief = (c) => ({ name: c.name, title: c.title, description: c.description, category: c.category, role: c.role, exports: c.exports, docs: c.docs, metadata: c.metadata ?? `metadata/components/${c.name}.json` })

/** Rank components for a free-text query. Higher is better; zero means no match. */
export function score(component, query) {
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean)
  if (terms.length === 0) return 0
  let total = 0
  for (const term of terms) {
    let best = 0
    const name = component.name.toLowerCase()
    if (name === term) best = 100
    else if (name.startsWith(term)) best = 60
    else if (name.includes(term)) best = 40
    if (component.title.toLowerCase().includes(term)) best = Math.max(best, 40)
    if (component.exports.some((e) => e.toLowerCase() === term)) best = Math.max(best, 50)
    else if (component.exports.some((e) => e.toLowerCase().includes(term))) best = Math.max(best, 25)
    if (component.role.toLowerCase().includes(term)) best = Math.max(best, 30)
    if (component.category.toLowerCase().includes(term)) best = Math.max(best, 20)
    if (component.description.toLowerCase().includes(term)) best = Math.max(best, 15)
    if (best === 0) return 0 // every term must match somewhere
    total += best
  }
  return total
}

const server = new McpServer({ name: "boilerplate-ui", version: pkg.version }, { instructions: `Read-only access to the ${pkg.name} design system: component metadata and design tokens. Call list_components or search_components first, then get_component for the props, variants, slots, accessibility contract and file paths of one component.` })
const readOnly = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }

server.registerTool(
  "list_components",
  {
    title: "List components",
    description: "List every component of the design system with its one-sentence description, category, ARIA role, exports and documentation path. Optionally filter by category.",
    inputSchema: { category: z.string().optional().describe("Category to filter by, for example form, overlay, navigation, feedback. Omit to list all.") },
    annotations: readOnly,
  },
  async ({ category }) => {
    const index = loadIndex()
    if (category && !index.categories.includes(category)) return failure(`unknown category "${category}"`, { categories: index.categories })
    const components = index.components.filter((c) => !category || c.category === category).map(brief)
    return reply({ package: index.package, version: index.version, count: components.length, categories: index.categories, components })
  },
)

server.registerTool(
  "get_component",
  {
    title: "Get component",
    description: "Return the full metadata of one component (props with type, default, required and description; variants; slots; data attributes; dependencies and required providers; ARIA role and keyboard interactions; version) and the paths of its source, documentation, example and test files.",
    inputSchema: { name: z.string().describe('Component name in kebab case as returned by list_components, for example "alert-dialog".') },
    annotations: readOnly,
  },
  async ({ name }) => {
    const index = loadIndex()
    const entry = index.components.find((c) => c.name === name)
    if (!entry) {
      const suggestions = index.components.map((c) => ({ name: c.name, s: score(c, name) })).filter((x) => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 5).map((x) => x.name)
      return failure(`unknown component "${name}"`, { suggestions, hint: "call list_components for the valid names" })
    }
    const metadata = readJson(`metadata/components/${entry.name}.json`)
    return reply({ name: entry.name, source: metadata.source, docs: metadata.docs, example: metadata.example, test: metadata.test, registryItem: `public/r/${entry.name}.json`, metadata })
  },
)

server.registerTool(
  "get_tokens",
  {
    title: "Get design tokens",
    description: "Return the design tokens in the W3C Design Tokens Format (2025.10). theme \"light\" (default) returns tokens/tokens.json, the complete set with light values. theme \"dark\" returns tokens/tokens.dark.json, the values that differ in the dark theme. tokens/resolver.json combines both.",
    inputSchema: { theme: z.enum(["light", "dark"]).optional().describe('"light" (default) or "dark".') },
    annotations: readOnly,
  },
  async ({ theme }) => {
    const file = theme === "dark" ? "tokens/tokens.dark.json" : "tokens/tokens.json"
    return reply({ theme: theme ?? "light", file, resolver: "tokens/resolver.json", cssSource: "src/theme/tokens.css", tokens: readJson(file) })
  },
)

server.registerTool(
  "search_components",
  {
    title: "Search components",
    description: "Search components by name, ARIA role, description, exported identifier or category. Every word of the query must match. Results are ranked; a match in the name ranks highest.",
    inputSchema: {
      query: z.string().min(1).describe('Words to search for, for example "date", "menu", "dialog modal" or "combobox".'),
      limit: z.number().int().min(1).max(50).optional().describe("Maximum number of results. Default 10."),
    },
    annotations: readOnly,
  },
  async ({ query, limit }) => {
    const index = loadIndex()
    const results = index.components
      .map((c) => ({ score: score(c, query), ...brief(c) }))
      .filter((r) => r.score > 0)
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      .slice(0, limit ?? 10)
    return reply({ query, count: results.length, results })
  },
)

// Start only when run as a program, so that the ranking function can be imported in tests.
if (process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await server.connect(new StdioServerTransport())
}
