import * as React from "react"
import { CalendarIcon, SettingsIcon, UserIcon } from "lucide-react"

import {
  Button,
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Command label="Commands" className="rounded-lg border">
      <CommandInput placeholder="Type a command" />
      <CommandList>
        <CommandEmpty>No command found.</CommandEmpty>
        <CommandItem>Open calendar</CommandItem>
        <CommandItem>Open settings</CommandItem>
      </CommandList>
    </Command>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [open, setOpen] = React.useState(false)
  const [last, setLast] = React.useState("none")
  const run = (name: string) => {
    setLast(name)
    setOpen(false)
  }

  return (
    <div className="grid gap-3">
      <div className="flex items-center gap-3">
        <Button variant="outline" onClick={() => setOpen(true)}>
          Open command palette
        </Button>
        <p className="text-sm text-muted-foreground" aria-live="polite">
          Last command: {last}
        </p>
      </div>
      <CommandDialog open={open} onOpenChange={setOpen} title="Command palette" description="Search for a command to run.">
        <CommandInput placeholder="Search commands" />
        <CommandList>
          <CommandEmpty>No command found.</CommandEmpty>
          <CommandGroup heading="Suggestions">
            <CommandItem onSelect={() => run("Calendar")}>
              <CalendarIcon aria-hidden="true" />
              Calendar
            </CommandItem>
            <CommandItem disabled>Calculator (unavailable)</CommandItem>
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Account">
            <CommandItem onSelect={() => run("Profile")}>
              <UserIcon aria-hidden="true" />
              Profile
              <CommandShortcut>⌘P</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => run("Settings")}>
              <SettingsIcon aria-hidden="true" />
              Settings
              <CommandShortcut>⌘S</CommandShortcut>
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </div>
  )
}
// #endregion composed
