import * as React from "react"

import { Label, Textarea } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="grid gap-2">
      <Label htmlFor="textarea-note">Note</Label>
      <Textarea id="textarea-note" placeholder="Add a note" />
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const limit = 120
  const [value, setValue] = React.useState("")
  const tooLong = value.length > limit
  return (
    <div className="grid max-w-md gap-4">
      <div className="grid gap-2">
        <Label htmlFor="textarea-feedback">Feedback</Label>
        <Textarea
          id="textarea-feedback"
          value={value}
          onChange={(event) => setValue(event.target.value)}
          aria-invalid={tooLong}
          aria-describedby="textarea-feedback-count"
          rows={3}
        />
        <p id="textarea-feedback-count" className={tooLong ? "text-sm text-destructive" : "text-sm text-muted-foreground"} aria-live="polite">
          {value.length} of {limit} characters{tooLong ? ". The text is too long." : ""}
        </p>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="textarea-disabled">Disabled</Label>
        <Textarea id="textarea-disabled" disabled defaultValue="This text cannot be changed." />
      </div>
    </div>
  )
}
// #endregion composed
