import * as React from "react"

import { Label, Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectSeparator, SelectTrigger, SelectValue } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="grid gap-2">
      <Label htmlFor="select-fruit">Fruit</Label>
      <Select>
        <SelectTrigger id="select-fruit" className="w-44">
          <SelectValue placeholder="Select a fruit" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="apple">Apple</SelectItem>
          <SelectItem value="banana">Banana</SelectItem>
          <SelectItem value="cherry">Cherry</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [zone, setZone] = React.useState("toronto")
  return (
    <div className="flex flex-wrap items-end gap-4">
      <div className="grid gap-2">
        <Label htmlFor="select-zone">Time zone</Label>
        <Select value={zone} onValueChange={setZone}>
          <SelectTrigger id="select-zone" size="default" className="w-52">
            <SelectValue placeholder="Select a time zone" />
          </SelectTrigger>
          <SelectContent position="popper">
            <SelectGroup>
              <SelectLabel>Europe</SelectLabel>
              <SelectItem value="berlin">Berlin</SelectItem>
              <SelectItem value="london">London</SelectItem>
            </SelectGroup>
            <SelectSeparator />
            <SelectGroup>
              <SelectLabel>America</SelectLabel>
              <SelectItem value="toronto">Toronto</SelectItem>
              <SelectItem value="new-york" disabled>
                New York (unavailable)
              </SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="select-rows">Rows</Label>
        <Select defaultValue="25">
          <SelectTrigger id="select-rows" size="sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="10">10</SelectItem>
            <SelectItem value="25">25</SelectItem>
            <SelectItem value="50">50</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="select-invalid">Category</Label>
        <Select>
          <SelectTrigger id="select-invalid" aria-invalid="true" className="w-44">
            <SelectValue placeholder="Required" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="bug">Bug</SelectItem>
            <SelectItem value="feature">Feature</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <p className="basis-full text-sm text-muted-foreground" aria-live="polite">
        Selected time zone: {zone}
      </p>
    </div>
  )
}
// #endregion composed
