import { CircleAlertIcon, InfoIcon } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Alert>
      <AlertTitle>Update available</AlertTitle>
      <AlertDescription>Restart the application to install version 2.4.</AlertDescription>
    </Alert>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid gap-3">
      <Alert variant="default">
        <InfoIcon aria-hidden="true" />
        <AlertTitle>Scheduled maintenance</AlertTitle>
        <AlertDescription>The service is read-only on Sunday from 02:00 to 04:00.</AlertDescription>
      </Alert>
      <Alert variant="destructive">
        <CircleAlertIcon aria-hidden="true" />
        <AlertTitle>Payment failed</AlertTitle>
        <AlertDescription>
          <p>The card was declined. Check the card number and try again.</p>
        </AlertDescription>
      </Alert>
    </div>
  )
}
// #endregion composed
