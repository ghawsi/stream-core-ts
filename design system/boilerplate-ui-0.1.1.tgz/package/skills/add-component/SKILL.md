---
name: add-component
description: Add a new component to the @boilerplate/ui design system, or add one of its components to an application. Use when asked to create, port or install a component, so that the source, example, test, metadata, documentation and registry item stay consistent.
---

# Add a component

Two procedures. Use **A** to add a component of this package to an application. Use **B** to add a new component to the package itself.

## A. Add a component to an application

1. Read `metadata/components/<name>.json`, or call the MCP tool `get_component` with the name. Note `dependencies.providers` and `dependencies.internal`.
2. Confirm that the application imports the stylesheet once, after Tailwind: `@import "@boilerplate/ui/styles.css";`.
3. Mount every provider that `dependencies.providers` marks as required, near the application root. `AGENTS.md`, section "Required providers", lists them.
4. Import the parts from the package root: `import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@boilerplate/ui"`.
5. Start from the `Minimal` example in `docs/components/<name>.md` and keep the nesting shown under "Anatomy".
6. Style with semantic token classes only (`bg-primary`, `text-muted-foreground`, `rounded-md`). Pass extra classes through `className`.
7. Give every icon-only button an `aria-label`, and every form control a label.

### Verification (A)

1. Run the application's type check (`tsc --noEmit`). It must report zero errors.
2. Render the page and confirm in the accessibility tree that every interactive element has a role and a name.
3. Operate the component with the keyboard only, using the keys listed under "Accessibility" in its documentation page.

## B. Add a new component to the package

1. Choose a kebab-case name, for example `stat-card`. Confirm that `metadata/components.json` has no component with that name.
2. Create `src/components/ui/<name>.tsx`:
   1. Declare each part as a function that takes `React.ComponentProps<"element">` (or the props of a Radix primitive), destructures `className`, and spreads the remaining props onto the rendered element.
   2. Write `data-slot="<name>"` on the root part and `data-slot="<name>-<part>"` on every other part.
   3. Merge classes with `cn()` from `cn`, with the caller's `className` last.
   4. Use semantic token classes only. Do not write colour literals, palette classes, arbitrary radii or arbitrary font sizes.
   5. If the component has `variant` or `size` props, define them with `cva()` and write `data-variant` and `data-size` on the element.
   6. Add `"use client"` as the first line only if the file uses state, effects, event handlers of its own or a client-only primitive.
   7. Export the parts in one `export { ... }` statement at the end of the file.
3. Create `examples/showcase/src/demos/<name>.tsx` with two exported components, each inside its region markers:
   1. `// #region minimal` ... `export function Minimal()` ... `// #endregion minimal`: the smallest useful usage.
   2. `// #region composed` ... `export function Composed()` ... `// #endregion composed`: realistic usage that shows every variant and size value.
   3. Import the parts from `@boilerplate/ui`, as an application would.
4. Create `tests/components/<name>.test.tsx` with `componentSuite("<name>", { Minimal, Composed, slots, interaction, run })` from `tests/helpers.tsx`. List the `data-slot` values in `slots`. In `run`, exercise the behaviour with `user` (click, keyboard); for a presentational part call `expectPassthrough`.
5. Add an entry for `<name>` to `scripts/data/components.info.json`: `description` (one sentence), `category`, `accessibility.role`, `accessibility.keyboard` (pairs of keys and action), `accessibility.notes`, and `providers` if the component needs one.
6. Run `npm run generate`. If it reports a prop without a description, add the description to `scripts/data/prop-descriptions.json` and run it again.
7. Add a line for the new component to the "Added" list in `scripts/build-changelog.mjs`, under a new version heading, and run `npm run changelog`.
8. Raise the minor version in `package.json` (a new component is a minor change).

### Verification (B)

Run each command. Every command must exit with code 0.

1. `npm run typecheck`
2. `npm run lint`
3. `npx vitest run tests/components/<name>.test.tsx`
4. `npm run check:hardcoded`
5. `npm run validate`
6. `npm run showcase:build && npm run showcase:axe && npm run showcase:screenshots`

Then confirm that these files exist and mention the component: `src/index.ts`, `metadata/components/<name>.json`, `docs/components/<name>.md`, `public/r/<name>.json`, `llms.txt`.

## Do not

- Do not edit a file under `src/components/ui/` that was ported from upstream. Add an entry to `scripts/deviations.mjs` and run `npm run port` instead.
- Do not edit generated files by hand (`AGENTS.md`, section "Do not change").
- Do not invent the `toast` component. Use `sonner` (`docs/components/sonner.md`).
