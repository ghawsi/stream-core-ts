---
name: theme-system
description: Change the brand colours, the radius scale or the chart colours of @boilerplate/ui, in an application or in the package, and verify the contrast of the result. Use when asked to re-theme, rebrand, change the primary colour, change the corner radius or add a token.
---

# Change the theme

Read `docs/theming.md` first if the token layer is new to you. Use procedure **A** for an application, which is the usual case. Use **B** only when the default theme of the package itself must change.

## A. Re-theme an application

1. Create a stylesheet for the override, for example `app/brand.css`. Do not edit files inside `node_modules/@boilerplate/ui`.
2. Import it after the package stylesheet:
   ```css
   @import "tailwindcss";
   @import "@boilerplate/ui/styles.css";
   @import "@boilerplate/ui/contrast-aa.css";
   @import "./brand.css";
   ```
3. Set the brand colour in OKLCH, in both blocks. Keep the token names; change only values.
   ```css
   :root {
     --primary: oklch(0.5 0.2 262);
     --primary-foreground: oklch(0.985 0 0);
     --ring: oklch(0.5 0.2 262);
   }
   .dark {
     --primary: oklch(0.72 0.15 262);
     --primary-foreground: oklch(0.2 0.04 262);
     --ring: oklch(0.72 0.15 262);
   }
   ```
4. Choose the lightness by theme: on the light page the brand colour is dark (lightness about 0.45 to 0.55) with light text; on the dark page it is light (about 0.7 to 0.8) with dark text.
5. Set `--sidebar-primary` and `--sidebar-primary-foreground` to the same pair if the application uses the sidebar.
6. To change the corners, set `--radius` in `:root`. Every step from `rounded-sm` to `rounded-4xl` follows.
7. To change chart colours, set `--chart-1` to `--chart-5` in `:root` and `.dark`. Refer to them in chart configs as `var(--chart-N)`.
8. Do not use `text-destructive-foreground`. Text on a destructive surface is `text-on-destructive`.

### Verification (A)

1. Run the contrast check with your file as the last overlay:
   ```bash
   node node_modules/@boilerplate/ui/scripts/check-contrast.mjs --overlay src/theme/contrast-aa.css,<absolute path to brand.css> --strict
   ```
   Paths are resolved against the package directory, so `src/theme/contrast-aa.css` is the file inside the package and your own file needs an absolute path. Inside the package repository the command is `node scripts/check-contrast.mjs --overlay src/theme/contrast-aa.css,<path> --strict`. The exit code must be 0. A failing line names the pair, the ratio and the block to change.
2. If a pair fails, change the lightness of the foreground or the background of that pair, in the named block, and run the check again. Repeat until the exit code is 0.
3. Open the application in the light and in the dark theme and look at a default button, a link-style button, a focused input and a chart.

## B. Change the package itself

1. To **add** a token, append an object to `tokenAdditions` in `scripts/deviations.mjs` with `name`, `light`, `dark`, `description` and a deviation identifier.
2. To use the token in an upstream component, add an entry to `deviations` in the same file (`file`, `find`, `replace`, `count`, `category`, `reason`).
3. Run `npm run port`. The script rewrites `src/theme/tokens.css` and the components. It fails if a `find` text no longer matches.
4. If a component now uses a new foreground and background combination, add the pair to `TEXT_PAIRS` in `scripts/check-contrast.mjs`.
5. Run `npm run generate` to rebuild the token files, the typed names, the metadata, the registry, the documentation and the changelog.
6. Describe the visible effect of the new deviation in the `EFFECT` table of `scripts/build-changelog.mjs` and run `npm run changelog`.

Do not rename or remove a token, and do not change a value in section 1 of `src/theme/tokens.css`: applications override these names, and the values are the upstream values. A rename is a breaking change and needs a major version.

### Verification (B)

Run each command. Every command must exit with code 0.

1. `npm run check:contrast`
2. `node scripts/check-contrast.mjs --overlay src/theme/contrast-aa.css --strict`
3. `npm run check:hardcoded`
4. `npm run validate` (the token files must match the DTCG 2025.10 schemas)
5. `npm run typecheck && npm test`
6. `npm run showcase:build && npm run showcase:axe`

Then confirm that `tokens/tokens.json`, `tokens/tokens.dark.json` and `src/theme/tokens.ts` contain the new token, and that `CHANGELOG.md` lists it.
