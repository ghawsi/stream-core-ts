// No "use client" directive here, on purpose: a server component (for example the root
// layout of a Next.js application) must be able to call this function. A function
// exported from a client module can be rendered from the server, but not called.
import type { Theme } from "./ThemeProvider"

const DEFAULT_STORAGE_KEY = "ui-theme"
const MEDIA_QUERY = "(prefers-color-scheme: dark)"

/**
 * Returns a script body that applies the stored theme before first paint.
 * Use it in a server-rendered `<head>` to avoid a flash of the wrong theme:
 * `<script dangerouslySetInnerHTML={{ __html: getThemeScript() }} />`.
 * Pass the same `storageKey` and `defaultTheme` as to `ThemeProvider`.
 */
function getThemeScript(storageKey: string = DEFAULT_STORAGE_KEY, defaultTheme: Theme = "system"): string {
  const key = JSON.stringify(storageKey)
  const fallback = JSON.stringify(defaultTheme)
  return `(function(){try{var t=localStorage.getItem(${key})}catch(e){}if(t!=="light"&&t!=="dark"&&t!=="system")t=${fallback};var d=t==="dark"||(t==="system"&&window.matchMedia&&window.matchMedia("${MEDIA_QUERY}").matches);var e=document.documentElement;e.classList.toggle("dark",d);e.style.colorScheme=d?"dark":"light";e.setAttribute("data-theme",d?"dark":"light")})()`
}

export { getThemeScript }
