import { toast } from "sonner"

import { Button, Toaster } from "@boilerplate/ui"

// #region minimal
// Mount one Toaster in the application; raise toasts from anywhere with toast().
// The id scopes this example to its own Toaster.
export function Minimal() {
  return (
    <>
      <Toaster id="sonner-minimal" position="bottom-left" />
      <Button variant="outline" onClick={() => toast("Draft saved", { toasterId: "sonner-minimal" })}>
        Show toast
      </Button>
    </>
  )
}
// #endregion minimal

// #region composed
// These toasts go to the Toaster mounted at the application root.
export function Composed() {
  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="outline" onClick={() => toast.success("Profile updated")}>
        Success
      </Button>
      <Button variant="outline" onClick={() => toast.info("A new version is available")}>
        Info
      </Button>
      <Button variant="outline" onClick={() => toast.warning("Storage is almost full")}>
        Warning
      </Button>
      <Button variant="outline" onClick={() => toast.error("The file could not be uploaded", { description: "The file is larger than 10 MB." })}>
        Error
      </Button>
      <Button
        variant="outline"
        onClick={() =>
          toast("Message archived", {
            action: { label: "Undo", onClick: () => toast("Message restored") },
          })
        }
      >
        With action
      </Button>
      <Button variant="outline" onClick={() => toast.promise(new Promise((resolve) => setTimeout(resolve, 1500)), { loading: "Saving", success: "Saved", error: "Not saved" })}>
        Promise
      </Button>
    </div>
  )
}
// #endregion composed
