import { Button, Input, Label, Sheet, SheetClose, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle, SheetTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open sheet</Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Notifications</SheetTitle>
          <SheetDescription>There are no new notifications.</SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  )
}
// #endregion minimal

// #region composed
const sides = ["top", "right", "bottom", "left"] as const

export function Composed() {
  return (
    <div className="flex flex-wrap gap-2">
      {sides.map((side) => (
        <Sheet key={side}>
          <SheetTrigger asChild>
            <Button variant="outline">Open from {side}</Button>
          </SheetTrigger>
          <SheetContent side={side}>
            <SheetHeader>
              <SheetTitle>Edit address ({side})</SheetTitle>
              <SheetDescription>Change the delivery address of the order.</SheetDescription>
            </SheetHeader>
            <div className="grid gap-2 px-4">
              <Label htmlFor={`sheet-street-${side}`}>Street</Label>
              <Input id={`sheet-street-${side}`} defaultValue="12 King Street West" autoComplete="street-address" />
            </div>
            <SheetFooter>
              <SheetClose asChild>
                <Button>Save address</Button>
              </SheetClose>
              <SheetClose asChild>
                <Button variant="outline">Cancel</Button>
              </SheetClose>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      ))}
    </div>
  )
}
// #endregion composed
