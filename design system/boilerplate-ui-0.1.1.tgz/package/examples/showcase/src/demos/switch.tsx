import * as React from "react"

import { Label, Switch } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="flex items-center gap-2">
      <Switch id="switch-airplane" />
      <Label htmlFor="switch-airplane">Airplane mode</Label>
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [enabled, setEnabled] = React.useState(true)
  return (
    <div className="grid max-w-sm gap-4">
      <div className="flex items-center justify-between gap-4 rounded-md border p-3">
        <div className="grid gap-1">
          <Label htmlFor="switch-backups">Automatic backups</Label>
          <p id="switch-backups-description" className="text-sm text-muted-foreground">
            {enabled ? "A backup runs every night." : "Backups are off."}
          </p>
        </div>
        <Switch id="switch-backups" size="default" checked={enabled} onCheckedChange={setEnabled} aria-describedby="switch-backups-description" />
      </div>
      <div className="flex items-center gap-2">
        <Switch id="switch-small" size="sm" defaultChecked />
        <Label htmlFor="switch-small">Small size</Label>
      </div>
      <div className="flex items-center gap-2">
        <Switch id="switch-disabled" disabled />
        <Label htmlFor="switch-disabled">Disabled</Label>
      </div>
    </div>
  )
}
// #endregion composed
