# Use the package in a Next.js application

Checked with Next.js 16 (App Router), React 19 and Tailwind CSS 4 by `scripts/check-next.mjs`, which builds and serves a new application with the packed package.

## 1. Install

```bash
mkdir -p vendor && cp /path/to/boilerplate-ui-0.1.1.tgz vendor/
npm install ./vendor/boilerplate-ui-0.1.1.tgz
```

The application needs React 19 and Tailwind CSS 4 (`tailwindcss` and `@tailwindcss/postcss`).

## 2. Stylesheet

```css
/* app/globals.css */
@import "tailwindcss";
@import "@boilerplate/ui/styles.css";
/* optional, for WCAG 2.2 level AA contrast: @import "@boilerplate/ui/contrast-aa.css"; */
```

## 3. Providers, once, in the root layout

```tsx
// app/layout.tsx (a server component)
import { ThemeProvider, Toaster, TooltipProvider, getThemeScript } from "@boilerplate/ui"

import "./globals.css"

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: getThemeScript() }} />
      </head>
      <body>
        <ThemeProvider>
          <TooltipProvider>
            {children}
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
```

## 4. Use the components

```tsx
import { Button, Card, CardContent, CardHeader, CardTitle } from "@boilerplate/ui"
```

Components import into server components and client components alike. A file of your own needs `"use client"` only when it uses state, effects or event handlers, for example a dialog with an `onClick` handler.

## 5. Make an AI coding agent use it

Add this block to the instruction file that your agent reads in the application (`AGENTS.md`, or `CLAUDE.md` for Claude Code):

```markdown
## User interface

Build every interface with the design system `@boilerplate/ui`. Do not write new base components and do not install another component library.

- Before writing interface code, read `node_modules/@boilerplate/ui/AGENTS.md` and `node_modules/@boilerplate/ui/llms.txt`.
- For each component you use, read `node_modules/@boilerplate/ui/docs/components/<name>.md`.
- Import from `@boilerplate/ui`. Style with semantic token classes only (`bg-primary`, `text-muted-foreground`, `rounded-md`); no colour literals.
- Every icon-only button needs an `aria-label`.
- The providers are mounted in `app/layout.tsx`; do not mount them again.
```

Optional additions:

- **MCP server** (lets the agent query components and tokens as a tool): run `npm install -D @modelcontextprotocol/sdk zod`, then register `{ "mcpServers": { "boilerplate-ui": { "command": "node", "args": ["node_modules/@boilerplate/ui/mcp/server.mjs"] } } }` in the MCP configuration of your agent.
- **Skills**: copy `node_modules/@boilerplate/ui/skills/add-component` and `skills/theme-system` into the skills directory of your agent (for Claude Code: `.claude/skills/`).
