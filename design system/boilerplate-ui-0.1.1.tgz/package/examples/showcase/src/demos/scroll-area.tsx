import { ScrollArea, ScrollBar, Separator } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <ScrollArea className="h-24 rounded-md border" type="always">
      <div className="p-3 text-sm" tabIndex={0} role="group" aria-label="Release notes">
        {Array.from({ length: 12 }, (_, index) => (
          <p key={index}>Release note {index + 1}</p>
        ))}
      </div>
    </ScrollArea>
  )
}
// #endregion minimal

// #region composed
const tags = Array.from({ length: 30 }, (_, index) => `v1.${30 - index}.0`)

export function Composed() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <ScrollArea className="h-48 min-w-0 rounded-md border" type="always">
        <div className="p-3" tabIndex={0} role="group" aria-label="Versions">
          <h3 className="mb-2 text-sm font-medium">Versions</h3>
          {tags.map((tag) => (
            <div key={tag}>
              <div className="text-sm">{tag}</div>
              <Separator className="my-2" />
            </div>
          ))}
        </div>
      </ScrollArea>

      <ScrollArea className="min-w-0 rounded-md border whitespace-nowrap" type="always">
        <div className="flex w-max gap-3 p-3" tabIndex={0} role="group" aria-label="Screenshots">
          {[1, 2, 3, 4, 5, 6].map((index) => (
            <div key={index} className="flex h-28 w-40 shrink-0 items-center justify-center rounded-md bg-muted text-sm">
              Screenshot {index}
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
// #endregion composed
