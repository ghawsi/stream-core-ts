import { Bubble, BubbleContent, BubbleGroup, BubbleReactions } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Bubble>
      <BubbleContent>The build finished without errors.</BubbleContent>
    </Bubble>
  )
}
// #endregion minimal

// #region composed
const variants = ["default", "secondary", "muted", "tinted", "outline", "ghost", "destructive"] as const

export function Composed() {
  return (
    <div className="grid gap-6 sm:grid-cols-2">
      <BubbleGroup>
        {variants.map((variant) => (
          <Bubble key={variant} variant={variant} align="start">
            <BubbleContent>Variant {variant}</BubbleContent>
          </Bubble>
        ))}
      </BubbleGroup>

      <BubbleGroup className="gap-8">
        <Bubble variant="secondary" align="end">
          <BubbleContent>Aligned to the end, with a reaction below.</BubbleContent>
          <BubbleReactions side="bottom" align="end" role="img" aria-label="Reactions: thumbs up, 2">
            <span aria-hidden="true">👍 2</span>
          </BubbleReactions>
        </Bubble>
        <Bubble variant="muted" align="start">
          <BubbleContent>Aligned to the start, with a reaction above.</BubbleContent>
          <BubbleReactions side="top" align="start" role="img" aria-label="Reactions: party, 1">
            <span aria-hidden="true">🎉 1</span>
          </BubbleReactions>
        </Bubble>
        <Bubble variant="outline">
          <BubbleContent asChild>
            <button type="button">An interactive bubble rendered as a button</button>
          </BubbleContent>
        </Bubble>
      </BubbleGroup>
    </div>
  )
}
// #endregion composed
