/**
 * Returns true when the user asked the operating system to reduce motion.
 * Safe on the server and in environments without `matchMedia` (returns false).
 *
 * CSS animations and transitions are already shortened by the rule in
 * `src/theme/styles.css`. This helper is for motion driven by JavaScript,
 * for example the carousel scroll.
 */
export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return false
  }
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches
}
