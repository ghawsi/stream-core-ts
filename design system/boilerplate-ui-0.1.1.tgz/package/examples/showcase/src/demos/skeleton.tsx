import { Skeleton } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Skeleton className="h-4 w-48" />
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div aria-busy="true" aria-label="Loading profile" role="group" className="flex items-center gap-4">
      <Skeleton className="size-12 rounded-full" />
      <div className="grid gap-2">
        <Skeleton className="h-4 w-56" />
        <Skeleton className="h-4 w-40" />
      </div>
    </div>
  )
}
// #endregion composed
