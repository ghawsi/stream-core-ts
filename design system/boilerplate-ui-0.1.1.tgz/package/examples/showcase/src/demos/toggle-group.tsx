import * as React from "react"
import { AlignCenterIcon, AlignLeftIcon, AlignRightIcon, BoldIcon, ItalicIcon, UnderlineIcon } from "lucide-react"

import { ToggleGroup, ToggleGroupItem } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <ToggleGroup type="single" defaultValue="left" aria-label="Text alignment">
      <ToggleGroupItem value="left" aria-label="Align left">
        <AlignLeftIcon />
      </ToggleGroupItem>
      <ToggleGroupItem value="center" aria-label="Align centre">
        <AlignCenterIcon />
      </ToggleGroupItem>
      <ToggleGroupItem value="right" aria-label="Align right">
        <AlignRightIcon />
      </ToggleGroupItem>
    </ToggleGroup>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [formats, setFormats] = React.useState(["bold"])
  return (
    <div className="grid gap-4">
      <ToggleGroup type="multiple" variant="outline" size="default" value={formats} onValueChange={setFormats} aria-label="Text formatting">
        <ToggleGroupItem value="bold" aria-label="Bold">
          <BoldIcon />
        </ToggleGroupItem>
        <ToggleGroupItem value="italic" aria-label="Italic">
          <ItalicIcon />
        </ToggleGroupItem>
        <ToggleGroupItem value="underline" aria-label="Underline">
          <UnderlineIcon />
        </ToggleGroupItem>
      </ToggleGroup>
      <p className="text-sm text-muted-foreground" aria-live="polite">
        Active formats: {formats.length ? formats.join(", ") : "none"}
      </p>

      <ToggleGroup type="single" variant="default" size="sm" defaultValue="week" aria-label="Calendar range (small)">
        <ToggleGroupItem value="day">Day</ToggleGroupItem>
        <ToggleGroupItem value="week">Week</ToggleGroupItem>
        <ToggleGroupItem value="month">Month</ToggleGroupItem>
      </ToggleGroup>

      <ToggleGroup type="single" variant="outline" size="lg" spacing={2} defaultValue="grid" aria-label="Layout (large, spaced)">
        <ToggleGroupItem value="list">List</ToggleGroupItem>
        <ToggleGroupItem value="grid">Grid</ToggleGroupItem>
        <ToggleGroupItem value="board" disabled>
          Board
        </ToggleGroupItem>
      </ToggleGroup>
    </div>
  )
}
// #endregion composed
