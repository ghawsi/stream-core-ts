import { Separator } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="text-sm">
      <p>Account</p>
      <Separator className="my-3" />
      <p>Billing</p>
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid gap-4 text-sm">
      <div>
        <h3 className="font-medium">Design system</h3>
        <p className="text-muted-foreground">Tokens, components and documentation.</p>
      </div>
      <Separator decorative={false} />
      <div className="flex h-5 items-center gap-4">
        <a href="#separator">Docs</a>
        <Separator orientation="vertical" />
        <a href="#separator">Source</a>
        <Separator orientation="vertical" />
        <a href="#separator">Changelog</a>
      </div>
    </div>
  )
}
// #endregion composed
