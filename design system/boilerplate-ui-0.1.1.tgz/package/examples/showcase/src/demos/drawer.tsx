import * as React from "react"
import { MinusIcon, PlusIcon } from "lucide-react"

import {
  Button,
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Drawer>
      <DrawerTrigger asChild>
        <Button variant="outline">Open drawer</Button>
      </DrawerTrigger>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Filters</DrawerTitle>
          <DrawerDescription>Narrow the list of results.</DrawerDescription>
        </DrawerHeader>
        <DrawerFooter>
          <DrawerClose asChild>
            <Button variant="outline">Close</Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [goal, setGoal] = React.useState(350)
  return (
    <Drawer>
      <DrawerTrigger asChild>
        <Button>Set daily goal</Button>
      </DrawerTrigger>
      <DrawerContent>
        <div className="mx-auto w-full max-w-sm">
          <DrawerHeader>
            <DrawerTitle>Daily goal</DrawerTitle>
            <DrawerDescription>Set the number of calories for one day.</DrawerDescription>
          </DrawerHeader>
          <div className="flex items-center justify-center gap-4 p-4">
            <Button variant="outline" size="icon" aria-label="Decrease goal by 10" onClick={() => setGoal((value) => Math.max(200, value - 10))} disabled={goal <= 200}>
              <MinusIcon />
            </Button>
            <output className="w-24 text-center text-4xl font-semibold tabular-nums" aria-live="polite" aria-label="Calories per day">
              {goal}
            </output>
            <Button variant="outline" size="icon" aria-label="Increase goal by 10" onClick={() => setGoal((value) => Math.min(400, value + 10))} disabled={goal >= 400}>
              <PlusIcon />
            </Button>
          </div>
          <DrawerFooter>
            <DrawerClose asChild>
              <Button>Save goal</Button>
            </DrawerClose>
            <DrawerClose asChild>
              <Button variant="outline">Cancel</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}
// #endregion composed
