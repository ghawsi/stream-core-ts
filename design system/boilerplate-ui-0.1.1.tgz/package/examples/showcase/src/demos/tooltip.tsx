import { CopyIcon, TrashIcon } from "lucide-react"

import { Button, Kbd, Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@boilerplate/ui"

// #region minimal
// TooltipProvider is required once, near the root of the application.
export function Minimal() {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline">Hover or focus</Button>
        </TooltipTrigger>
        <TooltipContent>Opens the settings page</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex flex-wrap items-center gap-3">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="icon" aria-label="Copy link">
              <CopyIcon />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="top">
            Copy link <Kbd>⌘C</Kbd>
          </TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="icon" aria-label="Delete item">
              <TrashIcon />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" sideOffset={6}>
            Delete item
          </TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="link" size="sm" className="underline decoration-dotted">
              SLA
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">Service level agreement</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  )
}
// #endregion composed
