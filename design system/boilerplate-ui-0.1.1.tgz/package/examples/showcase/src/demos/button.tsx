import { ArrowRightIcon, PlusIcon } from "lucide-react"

import { Button, Spinner } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Button>Save changes</Button>
}
// #endregion minimal

// #region composed
const variants = ["default", "secondary", "outline", "ghost", "link", "destructive"] as const
const textSizes = ["xs", "sm", "default", "lg"] as const
const iconSizes = ["icon-xs", "icon-sm", "icon", "icon-lg"] as const

export function Composed() {
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-2">
        {variants.map((variant) => (
          <Button key={variant} variant={variant}>
            {variant}
          </Button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {textSizes.map((size) => (
          <Button key={size} size={size} variant="outline">
            Size {size}
          </Button>
        ))}
        {iconSizes.map((size) => (
          <Button key={size} size={size} variant="outline" aria-label={`Add item (${size})`}>
            <PlusIcon />
          </Button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button>
          Continue
          <ArrowRightIcon aria-hidden="true" />
        </Button>
        <Button disabled>
          <Spinner aria-hidden="true" />
          Saving
        </Button>
        <Button variant="outline" disabled>
          Disabled
        </Button>
        <Button asChild variant="secondary">
          <a href="#button">Rendered as a link</a>
        </Button>
      </div>
    </div>
  )
}
// #endregion composed
