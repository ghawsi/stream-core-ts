import { Checkbox, Input, Label } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <div className="grid gap-2">
      <Label htmlFor="label-city">City</Label>
      <Input id="label-city" autoComplete="address-level2" />
    </div>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid max-w-sm gap-4">
      <div className="grid gap-2">
        <Label htmlFor="label-required">
          Company <span className="text-destructive" aria-hidden="true">*</span>
        </Label>
        <Input id="label-required" required aria-required="true" autoComplete="organization" />
      </div>
      <Label className="rounded-md border p-3">
        <Checkbox />
        The label wraps the control, so no id is needed.
      </Label>
      <div className="group grid gap-2" data-disabled="true">
        <Label htmlFor="label-disabled">Disabled field</Label>
        <Input id="label-disabled" disabled />
      </div>
    </div>
  )
}
// #endregion composed
