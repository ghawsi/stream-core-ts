import { ChevronDownIcon, MinusIcon, PlusIcon } from "lucide-react"

import { Button, ButtonGroup, ButtonGroupSeparator, ButtonGroupText, Input } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <ButtonGroup aria-label="Text alignment">
      <Button variant="outline">Left</Button>
      <Button variant="outline">Centre</Button>
      <Button variant="outline">Right</Button>
    </ButtonGroup>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-start gap-6">
      <ButtonGroup orientation="horizontal" aria-label="Save options">
        <Button variant="secondary">Save</Button>
        <ButtonGroupSeparator />
        <Button variant="secondary" size="icon" aria-label="More save options">
          <ChevronDownIcon />
        </Button>
      </ButtonGroup>

      <ButtonGroup aria-label="Website address">
        <ButtonGroupText asChild>
          <label htmlFor="button-group-url">https://</label>
        </ButtonGroupText>
        <Input id="button-group-url" placeholder="example.com" className="w-40" />
      </ButtonGroup>

      <ButtonGroup orientation="vertical" aria-label="Quantity">
        <Button variant="outline" size="icon" aria-label="Increase quantity">
          <PlusIcon />
        </Button>
        <Button variant="outline" size="icon" aria-label="Decrease quantity">
          <MinusIcon />
        </Button>
      </ButtonGroup>
    </div>
  )
}
// #endregion composed
