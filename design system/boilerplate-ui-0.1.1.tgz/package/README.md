# @boilerplate/ui

A React design system of 61 components, built from [shadcn/ui](https://ui.shadcn.com/) (style `new-york-v4`) on Radix UI primitives, TypeScript in strict mode and Tailwind CSS v4. Every component is documented, described in machine-readable metadata, demonstrated in a showcase and tested. The package is written for two readers: developers, and AI coding agents (see `AGENTS.md` and `llms.txt`).

Status: version 0.1.0. What was verified, and what was not, is recorded in `docs/VERIFICATION.md`.

## Requirements

- React 19 and React DOM 19
- Tailwind CSS 4
- Node.js 20.19 or later for the tooling

## Install

```bash
npm install @boilerplate/ui
```

The package is not published to a registry yet. Until it is, install it from the directory or from a packed archive (`npm pack`, then `npm install ./boilerplate-ui-0.1.0.tgz`).

Add the stylesheet once, after Tailwind:

```css
/* app/globals.css */
@import "tailwindcss";
@import "@boilerplate/ui/styles.css";
```

`styles.css` loads the token layer (light and dark), the animation utilities, the base rules and the reduced-motion rule, and it tells Tailwind to scan the package for class names.

Mount the providers near the root:

```tsx
import { ThemeProvider, Toaster, TooltipProvider } from "@boilerplate/ui"

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <TooltipProvider>
            {children}
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
```

To avoid a flash of the wrong theme in a server-rendered application, put `getThemeScript()` in the document head:

```tsx
import { getThemeScript } from "@boilerplate/ui"

<head>
  <script dangerouslySetInnerHTML={{ __html: getThemeScript() }} />
</head>
```

For a Next.js application, `docs/nextjs.md` has the same steps in one place, together with the instructions for an AI coding agent.

## Use

```tsx
import { Button, Card, CardContent, CardHeader, CardTitle } from "@boilerplate/ui"

export function Example() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Storage</CardTitle>
      </CardHeader>
      <CardContent>
        <Button variant="outline" size="sm">
          Upgrade
        </Button>
      </CardContent>
    </Card>
  )
}
```

A single component can also be imported by path: `import { Button } from "@boilerplate/ui/components/button"`.

Each component has a page in `docs/components/` with its anatomy, props, variants, two examples, accessibility notes and dependencies. Start from `llms.txt` or `metadata/components.json` for the full list.

### Alternative: copy the source with the shadcn command-line tool

The components are also a shadcn registry (`registry.json`, built items in `public/r/`). Serve `public/r/` over HTTP, add the registry to the `components.json` of the application, and install items by name:

```json
{ "registries": { "@boilerplate": "https://<host>/r/{name}.json" } }
```

```bash
npx shadcn@latest add @boilerplate/theme @boilerplate/button
```

## Theming

Colours, radii and chart colours are CSS custom properties with a light value (`:root`) and a dark value (`.dark`). `ThemeProvider` sets the `dark` class. To re-theme, override the variables in your own stylesheet after the import; `docs/theming.md` has a worked example and the contrast check that goes with it.

The default theme keeps the upstream shadcn/ui values. Five colour combinations that the components use are below the 4.5:1 contrast threshold with those values. `@boilerplate/ui/contrast-aa.css` is an optional layer that raises them; see `docs/theming.md`, section "Contrast".

## For AI agents

| File | Purpose |
|---|---|
| `AGENTS.md` | Commands, conventions, required providers, what must not be changed |
| `llms.txt` | Curated index of the documentation |
| `metadata/components.json`, `metadata/components/<name>.json` | Props, variants, slots, dependencies, accessibility, as JSON |
| `tokens/tokens.json`, `tokens/tokens.dark.json`, `tokens/resolver.json` | W3C Design Tokens (2025.10) |
| `registry.json`, `public/r/` | shadcn registry |
| `mcp/server.mjs` | Read-only Model Context Protocol server |
| `skills/` | Step-by-step procedures in the Agent Skills format |
| `evals/` | Evaluation tasks for agents, with their checks |

## Repository layout

```
src/                 components, hook, utility, theme (the package source)
tokens/              design tokens in the W3C format
metadata/            machine-readable component descriptions
docs/                component pages, theming guide, audit, verification record
examples/showcase/   every component and variant, light and dark
examples/theming/    the worked theming example
tests/               one test file per component, plus theme and utility tests
scripts/             generators and checks (non-interactive, --json)
mcp/                 Model Context Protocol server
skills/              agent skills
evals/               agent evaluation tasks
public/r/            built shadcn registry items
```

## Develop and contribute

```bash
npm install
npm run showcase:dev      # work on a component with live reload
npm run typecheck && npm run lint && npm test
npm run verify            # every check, written to docs/VERIFICATION.md
```

1. The components under `src/components/ui/` are ported from upstream by `npm run port`. To change one, add an entry to `scripts/deviations.mjs`; the entry is applied on every port and appears in `CHANGELOG.md`.
2. To add a component, follow `skills/add-component/SKILL.md`.
3. Generated files are not edited by hand; change the generator or its input (`AGENTS.md`, "Do not change").
4. A change is complete when `npm run verify` passes and `CHANGELOG.md` records it.

To update to a newer shadcn/ui: check out the newer upstream commit, run `npm run port -- --upstream <path>`, resolve any deviation that no longer matches, then run `npm run generate` and `npm run verify`.

## Licence

MIT. The components are derived from shadcn/ui, Copyright (c) 2023 shadcn; see `LICENSE.md`, which is the upstream licence text, unchanged. Schemas under `scripts/schemas/` keep their own licences (`scripts/schemas/README.md`).
