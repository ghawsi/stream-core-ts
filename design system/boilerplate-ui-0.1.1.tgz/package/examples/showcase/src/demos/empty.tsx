import { FolderOpenIcon } from "lucide-react"

import { Button, Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Empty className="border">
      <EmptyHeader>
        <EmptyTitle>No results</EmptyTitle>
        <EmptyDescription>Try a different search term.</EmptyDescription>
      </EmptyHeader>
    </Empty>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Empty className="border">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <FolderOpenIcon aria-hidden="true" />
          </EmptyMedia>
          <EmptyTitle>No projects yet</EmptyTitle>
          <EmptyDescription>Create a project to start tracking work.</EmptyDescription>
        </EmptyHeader>
        <EmptyContent>
          <div className="flex gap-2">
            <Button>Create project</Button>
            <Button variant="outline">Import</Button>
          </div>
        </EmptyContent>
      </Empty>
      <Empty className="border">
        <EmptyHeader>
          <EmptyMedia variant="default">
            <span className="text-4xl" aria-hidden="true">
              404
            </span>
          </EmptyMedia>
          <EmptyTitle>Page not found</EmptyTitle>
          <EmptyDescription>
            The address may be wrong. <a href="#empty">Go to the start page</a>.
          </EmptyDescription>
        </EmptyHeader>
      </Empty>
    </div>
  )
}
// #endregion composed
