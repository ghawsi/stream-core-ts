import { DirectionProvider, Tabs, TabsContent, TabsList, TabsTrigger, useDirection } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <DirectionProvider direction="rtl">
      <p dir="rtl" lang="fa" className="text-sm">
        این متن از راست به چپ نوشته می‌شود.
      </p>
    </DirectionProvider>
  )
}
// #endregion minimal

// #region composed
function CurrentDirection() {
  const direction = useDirection()
  return (
    <p className="text-sm text-muted-foreground">
      useDirection() returns <code>{direction}</code>
    </p>
  )
}

export function Composed() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {(["ltr", "rtl"] as const).map((direction) => (
        <DirectionProvider key={direction} direction={direction}>
          <div dir={direction} className="grid gap-2 rounded-md border p-3">
            <CurrentDirection />
            <Tabs defaultValue="one" dir={direction}>
              <TabsList aria-label={`Tabs in ${direction} order`}>
                <TabsTrigger value="one">First</TabsTrigger>
                <TabsTrigger value="two">Second</TabsTrigger>
              </TabsList>
              <TabsContent value="one">Arrow keys follow the reading direction.</TabsContent>
              <TabsContent value="two">The second panel.</TabsContent>
            </Tabs>
          </div>
        </DirectionProvider>
      ))}
    </div>
  )
}
// #endregion composed
