import * as React from "react"
import { ChevronsUpDownIcon } from "lucide-react"

import { Button, Collapsible, CollapsibleContent, CollapsibleTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Collapsible>
      <CollapsibleTrigger asChild>
        <Button variant="outline">Show details</Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="pt-2 text-sm">Order 1042 was shipped on 3 March.</CollapsibleContent>
    </Collapsible>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [open, setOpen] = React.useState(true)
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="grid max-w-xs gap-2">
      <div className="flex items-center justify-between gap-4">
        <h3 className="text-sm font-medium">3 repositories</h3>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="icon-sm" aria-label={open ? "Hide repositories" : "Show all repositories"}>
            <ChevronsUpDownIcon />
          </Button>
        </CollapsibleTrigger>
      </div>
      <div className="rounded-md border px-3 py-2 font-mono text-sm">design-system</div>
      <CollapsibleContent className="grid gap-2">
        <div className="rounded-md border px-3 py-2 font-mono text-sm">web-app</div>
        <div className="rounded-md border px-3 py-2 font-mono text-sm">api-gateway</div>
      </CollapsibleContent>
    </Collapsible>
  )
}
// #endregion composed
