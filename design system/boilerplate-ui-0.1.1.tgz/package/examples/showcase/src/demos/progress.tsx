import * as React from "react"

import { Button, Progress } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Progress value={40} aria-label="Upload progress" />
}
// #endregion minimal

// #region composed
export function Composed() {
  const [value, setValue] = React.useState(25)
  return (
    <div className="grid max-w-md gap-3">
      <div className="flex items-center justify-between text-sm">
        <span id="progress-label">Importing contacts</span>
        <span className="tabular-nums text-muted-foreground">{value}%</span>
      </div>
      <Progress value={value} aria-labelledby="progress-label" />
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={() => setValue((v) => Math.min(100, v + 25))} disabled={value >= 100}>
          Advance by 25%
        </Button>
        <Button size="sm" variant="ghost" onClick={() => setValue(0)}>
          Reset
        </Button>
      </div>
      <p role="status" className="text-sm text-muted-foreground">
        {value >= 100 ? "Import complete." : ""}
      </p>
    </div>
  )
}
// #endregion composed
