import { CheckIcon } from "lucide-react"

import { Badge } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Badge>New</Badge>
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Badge variant="default">Default</Badge>
      <Badge variant="secondary">Secondary</Badge>
      <Badge variant="destructive">Destructive</Badge>
      <Badge variant="outline">Outline</Badge>
      <Badge variant="ghost">Ghost</Badge>
      <Badge variant="link" asChild>
        <a href="#badge">Link</a>
      </Badge>
      <Badge variant="secondary">
        <CheckIcon aria-hidden="true" />
        Verified
      </Badge>
      <Badge variant="outline" className="tabular-nums">
        12
      </Badge>
    </div>
  )
}
// #endregion composed
