import * as React from "react"

import { Card, CardContent, Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, type CarouselApi } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Carousel aria-label="Featured items" className="mx-12 max-w-xs">
      <CarouselContent>
        {["One", "Two", "Three"].map((label) => (
          <CarouselItem key={label}>
            <div className="flex h-24 items-center justify-center rounded-md border text-lg font-medium">{label}</div>
          </CarouselItem>
        ))}
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [api, setApi] = React.useState<CarouselApi>()
  const [current, setCurrent] = React.useState(1)
  const slides = [1, 2, 3, 4, 5, 6]

  React.useEffect(() => {
    if (!api) return
    const onSelect = () => setCurrent(api.selectedScrollSnap() + 1)
    onSelect()
    api.on("select", onSelect)
    return () => {
      api.off("select", onSelect)
    }
  }, [api])

  return (
    <div className="mx-12 max-w-md">
      <Carousel setApi={setApi} opts={{ align: "start", loop: true }} aria-label="Product gallery">
        <CarouselContent>
          {slides.map((slide) => (
            <CarouselItem key={slide} className="basis-1/2" aria-label={`Slide ${slide} of ${slides.length}`}>
              <Card>
                <CardContent className="flex aspect-square items-center justify-center text-3xl font-semibold">{slide}</CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
      <p className="mt-2 text-center text-sm text-muted-foreground" aria-live="polite">
        Slide {current} of {slides.length}
      </p>
    </div>
  )
}
// #endregion composed
