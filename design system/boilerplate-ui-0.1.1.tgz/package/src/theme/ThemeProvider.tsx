"use client"

import * as React from "react"

export type Theme = "light" | "dark" | "system"
export type ResolvedTheme = "light" | "dark"

export interface ThemeContextValue {
  /** The stored preference: `light`, `dark` or `system`. */
  theme: Theme
  /** The theme in effect after `system` is resolved against the operating system. */
  resolvedTheme: ResolvedTheme
  /** Change the preference. The value is persisted when storage is available. */
  setTheme: (theme: Theme) => void
}

export interface ThemeProviderProps {
  children: React.ReactNode
  /** Preference used when nothing is stored. Default: `system`. */
  defaultTheme?: Theme
  /** `localStorage` key. Default: `ui-theme`. */
  storageKey?: string
  /** Element that receives the `dark` class. Default: `document.documentElement`. */
  target?: HTMLElement | null
}

const DEFAULT_STORAGE_KEY = "ui-theme"
const MEDIA_QUERY = "(prefers-color-scheme: dark)"
const THEMES: readonly Theme[] = ["light", "dark", "system"]

const ThemeContext = React.createContext<ThemeContextValue | null>(null)

function isTheme(value: unknown): value is Theme {
  return typeof value === "string" && (THEMES as readonly string[]).includes(value)
}

// Storage can throw: private browsing, a sandboxed iframe, a disabled cookie
// policy or a full quota. A failure must never break rendering.
function readStoredTheme(storageKey: string): Theme | null {
  try {
    const value = window.localStorage.getItem(storageKey)
    return isTheme(value) ? value : null
  } catch {
    return null
  }
}

function writeStoredTheme(storageKey: string, theme: Theme): void {
  try {
    window.localStorage.setItem(storageKey, theme)
  } catch {
    // The preference stays in memory for this session.
  }
}

function systemTheme(): ResolvedTheme {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return "light"
  }
  return window.matchMedia(MEDIA_QUERY).matches ? "dark" : "light"
}

/**
 * Provides light, dark and system colour modes.
 *
 * The provider toggles the `dark` class on the target element (the token layer
 * keys on `.dark`) and sets `color-scheme` so that native controls match.
 * Mount it once, near the root of the application.
 */
function ThemeProvider({ children, defaultTheme = "system", storageKey = DEFAULT_STORAGE_KEY, target }: ThemeProviderProps) {
  const [theme, setThemeState] = React.useState<Theme>(defaultTheme)
  const [system, setSystem] = React.useState<ResolvedTheme>("light")

  // Read the stored preference after mount so that server and client markup match.
  React.useEffect(() => {
    const stored = readStoredTheme(storageKey)
    if (stored) setThemeState(stored)
    setSystem(systemTheme())
  }, [storageKey])

  // Follow the operating system while the preference is `system`.
  React.useEffect(() => {
    if (typeof window.matchMedia !== "function") return
    const media = window.matchMedia(MEDIA_QUERY)
    const onChange = () => setSystem(media.matches ? "dark" : "light")
    media.addEventListener("change", onChange)
    return () => media.removeEventListener("change", onChange)
  }, [])

  // Keep several tabs of the same application in step.
  React.useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key === storageKey && isTheme(event.newValue)) setThemeState(event.newValue)
    }
    window.addEventListener("storage", onStorage)
    return () => window.removeEventListener("storage", onStorage)
  }, [storageKey])

  const resolvedTheme: ResolvedTheme = theme === "system" ? system : theme

  React.useEffect(() => {
    const element = target ?? document.documentElement
    element.classList.toggle("dark", resolvedTheme === "dark")
    element.style.colorScheme = resolvedTheme
    element.setAttribute("data-theme", resolvedTheme)
  }, [resolvedTheme, target])

  const setTheme = React.useCallback(
    (next: Theme) => {
      setThemeState(next)
      writeStoredTheme(storageKey, next)
    },
    [storageKey],
  )

  const value = React.useMemo<ThemeContextValue>(() => ({ theme, resolvedTheme, setTheme }), [theme, resolvedTheme, setTheme])

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
}

const FALLBACK: ThemeContextValue = {
  theme: "system",
  resolvedTheme: "light",
  setTheme: () => {},
}

/**
 * Reads the current theme. Outside a `ThemeProvider` it returns
 * `{ theme: "system", resolvedTheme: "light" }` and a no-op setter, so that
 * components such as `Toaster` still render.
 */
function useTheme(): ThemeContextValue {
  return React.useContext(ThemeContext) ?? FALLBACK
}

export { ThemeProvider, useTheme }
