import { Tabs, TabsContent, TabsList, TabsTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Tabs defaultValue="account">
      <TabsList aria-label="Settings sections">
        <TabsTrigger value="account">Account</TabsTrigger>
        <TabsTrigger value="password">Password</TabsTrigger>
      </TabsList>
      <TabsContent value="account">Change the name and email of the account.</TabsContent>
      <TabsContent value="password">Change the password.</TabsContent>
    </Tabs>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <div className="grid gap-6">
      <Tabs defaultValue="overview">
        <TabsList variant="default" aria-label="Project views">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="archive" disabled>
            Archive
          </TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="text-sm">
          12 open tasks, 3 due this week.
        </TabsContent>
        <TabsContent value="activity" className="text-sm">
          Ada closed 4 tasks yesterday.
        </TabsContent>
      </Tabs>

      <Tabs defaultValue="code">
        <TabsList variant="line" aria-label="Preview and code">
          <TabsTrigger value="preview">Preview</TabsTrigger>
          <TabsTrigger value="code">Code</TabsTrigger>
        </TabsList>
        <TabsContent value="preview" className="text-sm">
          The rendered component.
        </TabsContent>
        <TabsContent value="code" className="font-mono text-sm">
          {"<Button>Save</Button>"}
        </TabsContent>
      </Tabs>

      <Tabs defaultValue="general" orientation="vertical">
        <TabsList aria-label="Settings (vertical)">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>
        <TabsContent value="general" className="text-sm">
          Language and time zone.
        </TabsContent>
        <TabsContent value="billing" className="text-sm">
          Invoices and payment method.
        </TabsContent>
      </Tabs>
    </div>
  )
}
// #endregion composed
