import * as React from "react"

import { Slider } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return <Slider defaultValue={[40]} max={100} step={1} aria-label="Volume" />
}
// #endregion minimal

// #region composed
export function Composed() {
  const [price, setPrice] = React.useState([20, 80])
  return (
    <div className="grid max-w-md gap-6">
      <div className="grid gap-3">
        <div className="flex items-center justify-between text-sm">
          <span id="slider-price-label">Price range</span>
          <output className="tabular-nums text-muted-foreground" aria-live="polite">
            {price[0]} to {price[1]} EUR
          </output>
        </div>
        <Slider value={price} onValueChange={setPrice} min={0} max={100} step={5} aria-labelledby="slider-price-label" />
      </div>
      <div className="flex h-32 items-start gap-8">
        <Slider defaultValue={[60]} orientation="vertical" aria-label="Brightness" />
        <Slider defaultValue={[30]} disabled aria-label="Disabled slider" className="w-40" />
      </div>
    </div>
  )
}
// #endregion composed
