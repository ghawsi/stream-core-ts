import { Button, Input, Label, Popover, PopoverContent, PopoverDescription, PopoverHeader, PopoverTitle, PopoverTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline">Open popover</Button>
      </PopoverTrigger>
      <PopoverContent aria-label="Information">The popover stays open until it is dismissed.</PopoverContent>
    </Popover>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline">Set dimensions</Button>
      </PopoverTrigger>
      <PopoverContent className="w-72" align="start" sideOffset={8} aria-labelledby="popover-title" aria-describedby="popover-description">
        <PopoverHeader>
          <PopoverTitle id="popover-title">Dimensions</PopoverTitle>
          <PopoverDescription id="popover-description">Set the size of the layer in pixels.</PopoverDescription>
        </PopoverHeader>
        <div className="mt-3 grid gap-2">
          <div className="grid grid-cols-3 items-center gap-3">
            <Label htmlFor="popover-width">Width</Label>
            <Input id="popover-width" type="number" defaultValue={320} className="col-span-2 h-8" />
          </div>
          <div className="grid grid-cols-3 items-center gap-3">
            <Label htmlFor="popover-height">Height</Label>
            <Input id="popover-height" type="number" defaultValue={200} className="col-span-2 h-8" />
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}
// #endregion composed
