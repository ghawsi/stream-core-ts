import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <ResizablePanelGroup orientation="horizontal" className="h-24 rounded-md border">
      <ResizablePanel defaultSize="50%" className="flex items-center justify-center text-sm">
        Left
      </ResizablePanel>
      <ResizableHandle aria-label="Resize left and right panels" />
      <ResizablePanel defaultSize="50%" className="flex items-center justify-center text-sm">
        Right
      </ResizablePanel>
    </ResizablePanelGroup>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <ResizablePanelGroup orientation="horizontal" className="h-56 rounded-md border">
      <ResizablePanel defaultSize="30%" minSize="15%" className="flex items-center justify-center p-3 text-sm">
        Navigation
      </ResizablePanel>
      <ResizableHandle withHandle aria-label="Resize navigation" />
      <ResizablePanel defaultSize="70%">
        <ResizablePanelGroup orientation="vertical">
          <ResizablePanel defaultSize="60%" className="flex items-center justify-center p-3 text-sm">
            Editor
          </ResizablePanel>
          <ResizableHandle withHandle aria-label="Resize editor and terminal" />
          <ResizablePanel defaultSize="40%" className="flex items-center justify-center p-3 text-sm">
            Terminal
          </ResizablePanel>
        </ResizablePanelGroup>
      </ResizablePanel>
    </ResizablePanelGroup>
  )
}
// #endregion composed
