import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

import { Button, Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage, Input, Textarea } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  const form = useForm({ defaultValues: { name: "" } })
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(() => {})} className="grid gap-3">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input autoComplete="name" {...field} />
              </FormControl>
            </FormItem>
          )}
        />
        <Button type="submit">Submit</Button>
      </form>
    </Form>
  )
}
// #endregion minimal

// #region composed
const schema = z.object({
  email: z.string().email("Enter a valid email address."),
  message: z.string().min(10, "The message needs at least 10 characters."),
})

export function Composed() {
  const [sent, setSent] = React.useState<string | null>(null)
  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", message: "" },
  })

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((values) => setSent(values.email))} className="grid max-w-md gap-4" noValidate>
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" autoComplete="email" placeholder="name@example.com" {...field} />
              </FormControl>
              <FormDescription>The reply is sent to this address.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Message</FormLabel>
              <FormControl>
                <Textarea rows={3} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="justify-self-start">
          Send message
        </Button>
        <p role="status" className="text-sm text-muted-foreground">
          {sent ? `Message sent from ${sent}.` : ""}
        </p>
      </form>
    </Form>
  )
}
// #endregion composed
