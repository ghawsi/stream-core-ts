import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Accordion type="single" collapsible>
      <AccordionItem value="shipping">
        <AccordionTrigger>How long does shipping take?</AccordionTrigger>
        <AccordionContent>Orders arrive within three to five working days.</AccordionContent>
      </AccordionItem>
    </Accordion>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <Accordion type="multiple" defaultValue={["returns"]} className="w-full">
      <AccordionItem value="shipping">
        <AccordionTrigger>How long does shipping take?</AccordionTrigger>
        <AccordionContent>Orders arrive within three to five working days.</AccordionContent>
      </AccordionItem>
      <AccordionItem value="returns">
        <AccordionTrigger>Can I return an item?</AccordionTrigger>
        <AccordionContent>Yes. Unused items can be returned within 30 days of delivery.</AccordionContent>
      </AccordionItem>
      <AccordionItem value="support" disabled>
        <AccordionTrigger>Is phone support available?</AccordionTrigger>
        <AccordionContent>Phone support is not available yet.</AccordionContent>
      </AccordionItem>
    </Accordion>
  )
}
// #endregion composed
