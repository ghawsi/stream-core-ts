import * as React from "react"

import { InputOTP, InputOTPGroup, InputOTPSeparator, InputOTPSlot, Label } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <InputOTP maxLength={4} aria-label="Verification code">
      <InputOTPGroup>
        <InputOTPSlot index={0} />
        <InputOTPSlot index={1} />
        <InputOTPSlot index={2} />
        <InputOTPSlot index={3} />
      </InputOTPGroup>
    </InputOTP>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  const [value, setValue] = React.useState("")
  return (
    <div className="grid gap-2">
      <Label htmlFor="input-otp-code">One-time code</Label>
      <InputOTP id="input-otp-code" maxLength={6} value={value} onChange={setValue} aria-describedby="input-otp-status">
        <InputOTPGroup>
          <InputOTPSlot index={0} />
          <InputOTPSlot index={1} />
          <InputOTPSlot index={2} />
        </InputOTPGroup>
        <InputOTPSeparator />
        <InputOTPGroup>
          <InputOTPSlot index={3} />
          <InputOTPSlot index={4} />
          <InputOTPSlot index={5} />
        </InputOTPGroup>
      </InputOTP>
      <p id="input-otp-status" className="text-sm text-muted-foreground" aria-live="polite">
        {value.length === 6 ? `Code entered: ${value}` : `${6 - value.length} digits remaining`}
      </p>
    </div>
  )
}
// #endregion composed
