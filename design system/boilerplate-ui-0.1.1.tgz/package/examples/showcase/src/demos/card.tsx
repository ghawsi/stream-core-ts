import { Button, Card, CardAction, CardContent, CardDescription, CardFooter, CardHeader, CardTitle, Input, Label } from "@boilerplate/ui"

// #region minimal
export function Minimal() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Storage</CardTitle>
        <CardDescription>4.2 GB of 10 GB used</CardDescription>
      </CardHeader>
      <CardContent>Upgrade the plan to add more space.</CardContent>
    </Card>
  )
}
// #endregion minimal

// #region composed
export function Composed() {
  return (
    <Card className="max-w-sm">
      <CardHeader>
        <CardTitle>Sign in</CardTitle>
        <CardDescription>Enter the email address of your account.</CardDescription>
        <CardAction>
          <Button variant="link" size="sm">
            Create account
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent>
        <form id="card-sign-in" className="grid gap-4" onSubmit={(event) => event.preventDefault()}>
          <div className="grid gap-2">
            <Label htmlFor="card-email">Email</Label>
            <Input id="card-email" type="email" autoComplete="email" placeholder="name@example.com" required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="card-password">Password</Label>
            <Input id="card-password" type="password" autoComplete="current-password" required />
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex-col gap-2">
        <Button type="submit" form="card-sign-in" className="w-full">
          Sign in
        </Button>
        <Button variant="outline" className="w-full">
          Use a passkey
        </Button>
      </CardFooter>
    </Card>
  )
}
// #endregion composed
